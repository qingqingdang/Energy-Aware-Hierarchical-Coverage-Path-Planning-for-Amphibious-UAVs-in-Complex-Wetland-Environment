"""Analyze endurance and power from ArduPilot DataFlash flight logs.

Outputs are kept under Flight/Analysis:
  data/    CSV time series and summary tables
  figures/ SVG plots generated with the Python standard library
  reports/ Markdown report
"""

from __future__ import annotations

import csv
import datetime as dt
import html
import math
import statistics
import struct
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any


MAGIC = b"\xa3\x95"
GPS_UTC_LEAP_SECONDS = 18
CURRENT_THRESHOLD_A = 8.0
BIN_SECONDS = 5.0
BEIJING_TZ = dt.timezone(dt.timedelta(hours=8))
POWER_SPEED_BIN_MPS = 0.25
GPS_MATCH_MAX_AGE_S = 1.0
WIND_MATCH_MAX_AGE_S = 0.5

BATTERY_CAPACITY_MAH = {
    "00000157": 10000,
    "00000158": 12000,
    "00000161": 12000,
    "00000162": 12000,
}

FMT_DEF = {
    "name": "FMT",
    "len": 89,
    "fmt": "BBnNZ",
    "cols": ["Type", "Length", "Name", "Format", "Columns"],
}

FMT_CHARS = {
    "b": ("b", 1),
    "B": ("B", 1),
    "h": ("h", 2),
    "H": ("H", 2),
    "i": ("i", 4),
    "I": ("I", 4),
    "q": ("q", 8),
    "Q": ("Q", 8),
    "f": ("f", 4),
    "d": ("d", 8),
    "n": ("4s", 4),
    "N": ("16s", 16),
    "Z": ("64s", 64),
    "c": ("h", 2),
    "C": ("H", 2),
    "e": ("i", 4),
    "E": ("I", 4),
    "L": ("i", 4),
    "M": ("B", 1),
}

TEXT_FORMATS = {"n", "N", "Z"}


@dataclass
class BatterySample:
    log: str
    time_us: int
    time_s: float
    voltage_v: float
    resting_voltage_v: float
    current_a: float
    power_w: float
    capacity_used_mah: float
    energy_used_wh: float
    remaining_percent: float
    ground_speed_mps: float = math.nan
    ground_speed_kmh: float = math.nan
    ground_velocity_n_mps: float = math.nan
    ground_velocity_e_mps: float = math.nan
    wind_n_mps: float = math.nan
    wind_e_mps: float = math.nan
    estimated_airspeed_mps: float = math.nan
    estimated_airspeed_kmh: float = math.nan
    flight_time_s: float | None = None


@dataclass
class LogAnalysis:
    log: str
    capacity_mah: int
    full_samples: list[BatterySample]
    flight_samples: list[BatterySample]
    flight_start_s: float
    flight_end_s: float
    gps_first_utc: dt.datetime | None
    gps_last_utc: dt.datetime | None
    messages: list[str]
    modes: list[dict[str, Any]]
    record_counts: Counter[str]


def parse_c_string(raw: bytes) -> str:
    return raw.split(b"\0", 1)[0].decode("utf-8", "replace")


def decode_payload(fmt: str, cols: list[str], payload: bytes) -> dict[str, Any] | None:
    values: list[Any] = []
    offset = 0
    for char in fmt:
        if char not in FMT_CHARS:
            return None
        struct_fmt, size = FMT_CHARS[char]
        part = payload[offset : offset + size]
        offset += size
        if len(part) != size:
            return None
        if char in TEXT_FORMATS:
            value = parse_c_string(part)
        else:
            value = struct.unpack("<" + struct_fmt, part)[0]
        if char in "cCeE":
            value *= 0.01
        elif char == "L":
            value *= 1e-7
        values.append(value)
    return dict(zip(cols, values))


def gps_to_utc(gps_week: int, gps_millis: float) -> dt.datetime:
    return (
        dt.datetime(1980, 1, 6, tzinfo=dt.timezone.utc)
        + dt.timedelta(weeks=int(gps_week), milliseconds=float(gps_millis))
        - dt.timedelta(seconds=GPS_UTC_LEAP_SECONDS)
    )


def align_gps_speed(
    battery_samples: list[BatterySample],
    gps_speed_records: list[tuple[int, float, float, float]],
) -> None:
    if not battery_samples or not gps_speed_records:
        return

    gps_index = 0
    max_age_us = GPS_MATCH_MAX_AGE_S * 1_000_000
    for sample in battery_samples:
        while (
            gps_index + 1 < len(gps_speed_records)
            and abs(gps_speed_records[gps_index + 1][0] - sample.time_us)
            <= abs(gps_speed_records[gps_index][0] - sample.time_us)
        ):
            gps_index += 1
        gps_time_us, speed_mps, velocity_n, velocity_e = gps_speed_records[gps_index]
        if abs(gps_time_us - sample.time_us) <= max_age_us:
            sample.ground_speed_mps = speed_mps
            sample.ground_speed_kmh = speed_mps * 3.6
            sample.ground_velocity_n_mps = velocity_n
            sample.ground_velocity_e_mps = velocity_e


def align_estimated_airspeed(
    battery_samples: list[BatterySample],
    wind_records: list[tuple[int, float, float]],
) -> None:
    if not battery_samples or not wind_records:
        return

    window_us = WIND_MATCH_MAX_AGE_S * 1_000_000
    start_index = 0
    for sample in battery_samples:
        if math.isnan(sample.ground_velocity_n_mps) or math.isnan(sample.ground_velocity_e_mps):
            continue

        while start_index < len(wind_records) and wind_records[start_index][0] < sample.time_us - window_us:
            start_index += 1

        nearby: list[tuple[float, float]] = []
        index = start_index
        while index < len(wind_records) and wind_records[index][0] <= sample.time_us + window_us:
            nearby.append((wind_records[index][1], wind_records[index][2]))
            index += 1

        if not nearby:
            continue

        wind_n = statistics.fmean(item[0] for item in nearby)
        wind_e = statistics.fmean(item[1] for item in nearby)
        air_n = sample.ground_velocity_n_mps - wind_n
        air_e = sample.ground_velocity_e_mps - wind_e
        airspeed = math.hypot(air_n, air_e)

        sample.wind_n_mps = wind_n
        sample.wind_e_mps = wind_e
        sample.estimated_airspeed_mps = airspeed
        sample.estimated_airspeed_kmh = airspeed * 3.6


def parse_log(path: Path) -> tuple[list[BatterySample], dt.datetime | None, dt.datetime | None, list[str], list[dict[str, Any]], Counter[str]]:
    data = path.read_bytes()
    defs: dict[int, dict[str, Any]] = {128: FMT_DEF.copy()}
    counts: Counter[str] = Counter()
    battery_samples: list[BatterySample] = []
    gps_speed_records: list[tuple[int, float, float, float]] = []
    wind_records: list[tuple[int, float, float]] = []
    messages: list[str] = []
    modes: list[dict[str, Any]] = []
    first_time_us: int | None = None
    gps_first_utc: dt.datetime | None = None
    gps_last_utc: dt.datetime | None = None
    pos = 0

    while pos + 3 <= len(data):
        if data[pos : pos + 2] != MAGIC:
            next_pos = data.find(MAGIC, pos + 1)
            if next_pos < 0:
                break
            pos = next_pos
            continue

        msg_type = data[pos + 2]
        msg_def = defs.get(msg_type)
        if msg_def is None:
            next_pos = data.find(MAGIC, pos + 1)
            if next_pos < 0:
                break
            pos = next_pos
            continue

        total_len = int(msg_def["len"])
        if total_len < 3 or pos + total_len > len(data):
            break

        payload = data[pos + 3 : pos + total_len]
        name = str(msg_def["name"])
        counts[name] += 1
        rec = decode_payload(str(msg_def["fmt"]), list(msg_def["cols"]), payload)

        if name == "FMT" and rec:
            cols = [item for item in str(rec.get("Columns", "")).split(",") if item]
            defs[int(rec["Type"])] = {
                "name": rec["Name"],
                "len": int(rec["Length"]),
                "fmt": rec["Format"],
                "cols": cols,
            }
        elif rec:
            time_us = rec.get("TimeUS")
            if isinstance(time_us, int) and first_time_us is None:
                first_time_us = time_us

            if name == "BAT" and int(rec.get("Inst", 0)) == 0 and first_time_us is not None:
                voltage = float(rec.get("Volt", math.nan))
                current = float(rec.get("Curr", math.nan))
                sample = BatterySample(
                    log=path.name,
                    time_us=int(time_us),
                    time_s=(int(time_us) - first_time_us) / 1_000_000,
                    voltage_v=voltage,
                    resting_voltage_v=float(rec.get("VoltR", math.nan)),
                    current_a=current,
                    power_w=voltage * current,
                    capacity_used_mah=float(rec.get("CurrTot", math.nan)),
                    energy_used_wh=float(rec.get("EnrgTot", math.nan)),
                    remaining_percent=float(rec.get("RemPct", math.nan)),
                )
                battery_samples.append(sample)
            elif name == "GPS" and rec.get("GWk") is not None and rec.get("GMS") is not None:
                gps_time = gps_to_utc(int(rec["GWk"]), float(rec["GMS"]))
                gps_first_utc = gps_first_utc or gps_time
                gps_last_utc = gps_time
                if isinstance(time_us, int):
                    speed_mps = float(rec.get("Spd", math.nan))
                    course_rad = math.radians(float(rec.get("GCrs", math.nan)))
                    velocity_n = speed_mps * math.cos(course_rad)
                    velocity_e = speed_mps * math.sin(course_rad)
                    gps_speed_records.append((int(time_us), speed_mps, velocity_n, velocity_e))
            elif name == "XKF2" and isinstance(time_us, int):
                wind_n = float(rec.get("VWN", math.nan))
                wind_e = float(rec.get("VWE", math.nan))
                if not math.isnan(wind_n) and not math.isnan(wind_e):
                    wind_records.append((int(time_us), wind_n, wind_e))
            elif name == "MSG":
                msg = str(rec.get("Message", ""))
                if msg:
                    messages.append(msg)
            elif name == "MODE":
                modes.append(rec)

        pos += total_len

    align_gps_speed(battery_samples, gps_speed_records)
    align_estimated_airspeed(battery_samples, wind_records)
    return battery_samples, gps_first_utc, gps_last_utc, messages, modes, counts


def find_flight_window(samples: list[BatterySample]) -> tuple[float, float]:
    if not samples:
        return 0.0, 0.0

    bins: dict[int, list[float]] = {}
    for sample in samples:
        bin_index = int(sample.time_s // BIN_SECONDS)
        bins.setdefault(bin_index, []).append(sample.current_a)

    active_bins = sorted(
        bin_index
        for bin_index, currents in bins.items()
        if statistics.fmean(currents) > CURRENT_THRESHOLD_A
    )
    if not active_bins:
        return samples[0].time_s, samples[-1].time_s

    runs: list[tuple[int, int]] = []
    start = active_bins[0]
    previous = start
    for bin_index in active_bins[1:]:
        if bin_index == previous + 1:
            previous = bin_index
        else:
            runs.append((start, previous))
            start = bin_index
            previous = bin_index
    runs.append((start, previous))

    longest_start, longest_end = max(runs, key=lambda item: item[1] - item[0] + 1)
    return longest_start * BIN_SECONDS, (longest_end + 1) * BIN_SECONDS


def analyze_log(path: Path) -> LogAnalysis:
    samples, gps_first, gps_last, messages, modes, counts = parse_log(path)
    start_s, end_s = find_flight_window(samples)
    flight_samples = [s for s in samples if start_s <= s.time_s <= end_s]
    for sample in flight_samples:
        sample.flight_time_s = sample.time_s - start_s

    capacity = BATTERY_CAPACITY_MAH.get(path.stem, 0)
    return LogAnalysis(
        log=path.name,
        capacity_mah=capacity,
        full_samples=samples,
        flight_samples=flight_samples,
        flight_start_s=start_s,
        flight_end_s=end_s,
        gps_first_utc=gps_first,
        gps_last_utc=gps_last,
        messages=messages,
        modes=modes,
        record_counts=counts,
    )


def safe_mean(values: list[float]) -> float:
    valid = [value for value in values if not math.isnan(value)]
    return statistics.fmean(valid) if valid else math.nan


def stats(values: list[float]) -> dict[str, float]:
    valid = [value for value in values if not math.isnan(value)]
    if not valid:
        return {"min": math.nan, "mean": math.nan, "max": math.nan}
    return {"min": min(valid), "mean": statistics.fmean(valid), "max": max(valid)}


def summarize(analysis: LogAnalysis) -> dict[str, Any]:
    samples = analysis.flight_samples
    if not samples:
        raise ValueError(f"No flight samples found for {analysis.log}")

    voltage = stats([sample.voltage_v for sample in samples])
    current = stats([sample.current_a for sample in samples])
    power = stats([sample.power_w for sample in samples])
    speed = stats([sample.ground_speed_mps for sample in samples])
    airspeed = stats([sample.estimated_airspeed_mps for sample in samples])
    wind_speed = stats([math.hypot(sample.wind_n_mps, sample.wind_e_mps) for sample in samples])
    duration_min = (samples[-1].flight_time_s or 0.0) / 60.0
    capacity_used = samples[-1].capacity_used_mah - samples[0].capacity_used_mah
    energy_used = samples[-1].energy_used_wh - samples[0].energy_used_wh
    usable_ratio = capacity_used / analysis.capacity_mah if analysis.capacity_mah else math.nan

    return {
        "log": analysis.log,
        "battery_capacity_mAh": analysis.capacity_mah,
        "flight_start_s": analysis.flight_start_s,
        "flight_end_s": analysis.flight_end_s,
        "endurance_min": duration_min,
        "samples": len(samples),
        "capacity_used_mAh": capacity_used,
        "capacity_used_ratio": usable_ratio,
        "energy_used_Wh": energy_used,
        "mAh_per_min": capacity_used / duration_min if duration_min else math.nan,
        "Wh_per_min": energy_used / duration_min if duration_min else math.nan,
        "average_power_from_energy_W": energy_used / (duration_min / 60.0) if duration_min else math.nan,
        "voltage_min_V": voltage["min"],
        "voltage_mean_V": voltage["mean"],
        "voltage_max_V": voltage["max"],
        "current_min_A": current["min"],
        "current_mean_A": current["mean"],
        "current_max_A": current["max"],
        "power_min_W": power["min"],
        "power_mean_W": power["mean"],
        "power_max_W": power["max"],
        "speed_min_mps": speed["min"],
        "speed_mean_mps": speed["mean"],
        "speed_max_mps": speed["max"],
        "speed_mean_kmh": speed["mean"] * 3.6 if not math.isnan(speed["mean"]) else math.nan,
        "estimated_airspeed_min_mps": airspeed["min"],
        "estimated_airspeed_mean_mps": airspeed["mean"],
        "estimated_airspeed_max_mps": airspeed["max"],
        "estimated_airspeed_mean_kmh": airspeed["mean"] * 3.6 if not math.isnan(airspeed["mean"]) else math.nan,
        "ekf_wind_mean_mps": wind_speed["mean"],
        "ekf_wind_max_mps": wind_speed["max"],
    }


def write_battery_csv(path: Path, samples: list[BatterySample], flight_only: bool) -> None:
    fieldnames = [
        "log",
        "time_us",
        "time_s",
        "flight_time_s",
        "flight_time_min",
        "voltage_V",
        "resting_voltage_V",
        "current_A",
        "power_W",
        "ground_speed_mps",
        "ground_speed_kmh",
        "ground_velocity_n_mps",
        "ground_velocity_e_mps",
        "wind_n_mps",
        "wind_e_mps",
        "estimated_airspeed_mps",
        "estimated_airspeed_kmh",
        "capacity_used_mAh",
        "energy_used_Wh",
        "remaining_percent",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for sample in samples:
            flight_time_s = sample.flight_time_s if flight_only else None
            writer.writerow(
                {
                    "log": sample.log,
                    "time_us": sample.time_us,
                    "time_s": f"{sample.time_s:.6f}",
                    "flight_time_s": "" if flight_time_s is None else f"{flight_time_s:.6f}",
                    "flight_time_min": "" if flight_time_s is None else f"{flight_time_s / 60.0:.6f}",
                    "voltage_V": f"{sample.voltage_v:.6f}",
                    "resting_voltage_V": f"{sample.resting_voltage_v:.6f}",
                    "current_A": f"{sample.current_a:.6f}",
                    "power_W": f"{sample.power_w:.6f}",
                    "ground_speed_mps": f"{sample.ground_speed_mps:.6f}",
                    "ground_speed_kmh": f"{sample.ground_speed_kmh:.6f}",
                    "ground_velocity_n_mps": f"{sample.ground_velocity_n_mps:.6f}",
                    "ground_velocity_e_mps": f"{sample.ground_velocity_e_mps:.6f}",
                    "wind_n_mps": f"{sample.wind_n_mps:.6f}",
                    "wind_e_mps": f"{sample.wind_e_mps:.6f}",
                    "estimated_airspeed_mps": f"{sample.estimated_airspeed_mps:.6f}",
                    "estimated_airspeed_kmh": f"{sample.estimated_airspeed_kmh:.6f}",
                    "capacity_used_mAh": f"{sample.capacity_used_mah:.6f}",
                    "energy_used_Wh": f"{sample.energy_used_wh:.6f}",
                    "remaining_percent": f"{sample.remaining_percent:.6f}",
                }
            )


def write_summary_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    key: f"{value:.6f}" if isinstance(value, float) else value
                    for key, value in row.items()
                }
            )


def power_speed_points(analysis: LogAnalysis, speed_kind: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for sample in analysis.flight_samples:
        speed_mps = speed_value(sample, speed_kind)
        if math.isnan(speed_mps) or math.isnan(sample.power_w):
            continue
        rows.append(
            {
                "log": analysis.log,
                "speed_kind": speed_kind,
                "flight_time_s": sample.flight_time_s or 0.0,
                "flight_time_min": (sample.flight_time_s or 0.0) / 60.0,
                "speed_mps": speed_mps,
                "speed_kmh": speed_mps * 3.6,
                "power_W": sample.power_w,
                "current_A": sample.current_a,
                "voltage_V": sample.voltage_v,
                "ground_speed_mps": sample.ground_speed_mps,
                "wind_n_mps": sample.wind_n_mps,
                "wind_e_mps": sample.wind_e_mps,
            }
        )
    return rows


def binned_power_speed(analysis: LogAnalysis, speed_kind: str) -> list[dict[str, Any]]:
    bins: dict[int, list[BatterySample]] = {}
    for sample in analysis.flight_samples:
        speed_mps = speed_value(sample, speed_kind)
        if math.isnan(speed_mps) or math.isnan(sample.power_w):
            continue
        bin_index = int(speed_mps // POWER_SPEED_BIN_MPS)
        bins.setdefault(bin_index, []).append(sample)

    rows: list[dict[str, Any]] = []
    for bin_index in sorted(bins):
        samples = bins[bin_index]
        speeds = [speed_value(sample, speed_kind) for sample in samples]
        powers = [sample.power_w for sample in samples]
        currents = [sample.current_a for sample in samples]
        voltages = [sample.voltage_v for sample in samples]
        rows.append(
            {
                "log": analysis.log,
                "speed_kind": speed_kind,
                "speed_bin_start_mps": bin_index * POWER_SPEED_BIN_MPS,
                "speed_bin_end_mps": (bin_index + 1) * POWER_SPEED_BIN_MPS,
                "speed_bin_center_mps": (bin_index + 0.5) * POWER_SPEED_BIN_MPS,
                "mean_speed_mps": statistics.fmean(speeds),
                "mean_speed_kmh": statistics.fmean(speeds) * 3.6,
                "mean_power_W": statistics.fmean(powers),
                "mean_current_A": statistics.fmean(currents),
                "mean_voltage_V": statistics.fmean(voltages),
                "samples": len(samples),
            }
        )
    return rows


def speed_value(sample: BatterySample, speed_kind: str) -> float:
    if speed_kind == "ground_speed":
        return sample.ground_speed_mps
    if speed_kind == "estimated_airspeed":
        return sample.estimated_airspeed_mps
    raise ValueError(f"Unknown speed_kind: {speed_kind}")


def write_rows_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8-sig")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    key: f"{value:.6f}" if isinstance(value, float) else value
                    for key, value in row.items()
                }
            )


def scale_points(
    series: list[tuple[float, float]],
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
    left: float,
    top: float,
    width: float,
    height: float,
) -> str:
    points = []
    x_span = x_max - x_min or 1.0
    y_span = y_max - y_min or 1.0
    for x_value, y_value in series:
        x = left + (x_value - x_min) / x_span * width
        y = top + height - (y_value - y_min) / y_span * height
        points.append(f"{x:.2f},{y:.2f}")
    return " ".join(points)


def nice_limits(values: list[float]) -> tuple[float, float]:
    valid = [value for value in values if not math.isnan(value)]
    if not valid:
        return 0.0, 1.0
    lower = min(valid)
    upper = max(valid)
    if lower == upper:
        return lower - 1.0, upper + 1.0
    pad = (upper - lower) * 0.08
    return lower - pad, upper + pad


def make_svg_plot(
    path: Path,
    title: str,
    analyses: list[LogAnalysis],
    y_getters: list[tuple[str, str, Any]],
) -> None:
    width = 1200
    panel_height = 260
    margin_left = 85
    margin_right = 40
    margin_top = 70
    panel_gap = 58
    plot_width = width - margin_left - margin_right
    height = margin_top + len(y_getters) * panel_height + (len(y_getters) - 1) * panel_gap + 70
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd"]

    all_x = [
        (sample.flight_time_s or 0.0) / 60.0
        for analysis in analyses
        for sample in analysis.flight_samples
    ]
    x_min = 0.0
    x_max = max(all_x) if all_x else 1.0

    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="{width / 2:.1f}" y="32" text-anchor="middle" font-family="Arial" font-size="22" font-weight="700">{html.escape(title)}</text>',
    ]

    legend_x = margin_left + 180
    legend_y = 52
    for idx, analysis in enumerate(analyses):
        x = legend_x + idx * 230
        lines.append(f'<line x1="{x}" y1="{legend_y}" x2="{x + 34}" y2="{legend_y}" stroke="{colors[idx % len(colors)]}" stroke-width="3"/>')
        lines.append(f'<text x="{x + 42}" y="{legend_y + 5}" font-family="Arial" font-size="14">{html.escape(analysis.log)}</text>')

    for panel_idx, (field, ylabel, getter) in enumerate(y_getters):
        top = margin_top + panel_idx * (panel_height + panel_gap)
        all_y = [getter(sample) for analysis in analyses for sample in analysis.flight_samples]
        y_min, y_max = nice_limits(all_y)

        lines.append(f'<rect x="{margin_left}" y="{top}" width="{plot_width}" height="{panel_height}" fill="#fafafa" stroke="#cccccc"/>')
        lines.append(f'<text x="24" y="{top + panel_height / 2:.1f}" transform="rotate(-90 24 {top + panel_height / 2:.1f})" font-family="Arial" font-size="15" text-anchor="middle">{html.escape(ylabel)}</text>')
        lines.append(f'<text x="{margin_left}" y="{top - 10}" font-family="Arial" font-size="16" font-weight="700">{html.escape(field)}</text>')

        for grid_i in range(6):
            frac = grid_i / 5
            y = top + panel_height - frac * panel_height
            value = y_min + frac * (y_max - y_min)
            lines.append(f'<line x1="{margin_left}" y1="{y:.2f}" x2="{margin_left + plot_width}" y2="{y:.2f}" stroke="#e6e6e6"/>')
            lines.append(f'<text x="{margin_left - 8}" y="{y + 4:.2f}" font-family="Arial" font-size="12" text-anchor="end">{value:.1f}</text>')

        for grid_i in range(7):
            frac = grid_i / 6
            x = margin_left + frac * plot_width
            value = x_min + frac * (x_max - x_min)
            lines.append(f'<line x1="{x:.2f}" y1="{top}" x2="{x:.2f}" y2="{top + panel_height}" stroke="#eeeeee"/>')
            if panel_idx == len(y_getters) - 1:
                lines.append(f'<text x="{x:.2f}" y="{top + panel_height + 22}" font-family="Arial" font-size="12" text-anchor="middle">{value:.1f}</text>')

        for idx, analysis in enumerate(analyses):
            series = [
                ((sample.flight_time_s or 0.0) / 60.0, getter(sample))
                for sample in analysis.flight_samples
                if not math.isnan(getter(sample))
            ]
            if len(series) > 1200:
                stride = math.ceil(len(series) / 1200)
                series = series[::stride]
            points = scale_points(series, x_min, x_max, y_min, y_max, margin_left, top, plot_width, panel_height)
            lines.append(f'<polyline points="{points}" fill="none" stroke="{colors[idx % len(colors)]}" stroke-width="1.7"/>')

    lines.append(f'<text x="{width / 2:.1f}" y="{height - 22}" text-anchor="middle" font-family="Arial" font-size="15">Effective flight time (min)</text>')
    lines.append("</svg>")
    path.write_text("\n".join(lines), encoding="utf-8")


def make_power_speed_svg(path: Path, title: str, binned_rows: list[dict[str, Any]], x_label: str) -> None:
    width = 1200
    height = 720
    left = 90
    right = 40
    top = 86
    bottom = 78
    plot_width = width - left - right
    plot_height = height - top - bottom
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd"]

    logs = sorted({str(row["log"]) for row in binned_rows})
    x_values = [float(row["mean_speed_mps"]) for row in binned_rows]
    y_values = [float(row["mean_power_W"]) for row in binned_rows]
    x_min, x_max = nice_limits(x_values)
    y_min, y_max = nice_limits(y_values)
    x_min = max(0.0, x_min)

    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="{width / 2:.1f}" y="32" text-anchor="middle" font-family="Arial" font-size="22" font-weight="700">{html.escape(title)}</text>',
        f'<text x="{width / 2:.1f}" y="58" text-anchor="middle" font-family="Arial" font-size="14" fill="#555">Binned mean curve, bin width = {POWER_SPEED_BIN_MPS:.2f} m/s</text>',
        f'<rect x="{left}" y="{top}" width="{plot_width}" height="{plot_height}" fill="#fafafa" stroke="#cccccc"/>',
    ]

    legend_x = left + 190
    legend_y = 78
    for idx, log in enumerate(logs):
        x = legend_x + idx * 230
        color = colors[idx % len(colors)]
        lines.append(f'<line x1="{x}" y1="{legend_y}" x2="{x + 34}" y2="{legend_y}" stroke="{color}" stroke-width="3"/>')
        lines.append(f'<text x="{x + 42}" y="{legend_y + 5}" font-family="Arial" font-size="14">{html.escape(log)}</text>')

    for grid_i in range(7):
        frac = grid_i / 6
        x = left + frac * plot_width
        value = x_min + frac * (x_max - x_min)
        lines.append(f'<line x1="{x:.2f}" y1="{top}" x2="{x:.2f}" y2="{top + plot_height}" stroke="#eeeeee"/>')
        lines.append(f'<text x="{x:.2f}" y="{top + plot_height + 24}" font-family="Arial" font-size="12" text-anchor="middle">{value:.2f}</text>')

    for grid_i in range(7):
        frac = grid_i / 6
        y = top + plot_height - frac * plot_height
        value = y_min + frac * (y_max - y_min)
        lines.append(f'<line x1="{left}" y1="{y:.2f}" x2="{left + plot_width}" y2="{y:.2f}" stroke="#e6e6e6"/>')
        lines.append(f'<text x="{left - 8}" y="{y + 4:.2f}" font-family="Arial" font-size="12" text-anchor="end">{value:.0f}</text>')

    lines.append(f'<text x="{width / 2:.1f}" y="{height - 24}" text-anchor="middle" font-family="Arial" font-size="15">{html.escape(x_label)}</text>')
    lines.append(f'<text x="24" y="{top + plot_height / 2:.1f}" transform="rotate(-90 24 {top + plot_height / 2:.1f})" font-family="Arial" font-size="15" text-anchor="middle">Power (W)</text>')

    for idx, log in enumerate(logs):
        rows = [row for row in binned_rows if row["log"] == log and int(row["samples"]) >= 1]
        rows.sort(key=lambda row: float(row["mean_speed_mps"]))
        series = [(float(row["mean_speed_mps"]), float(row["mean_power_W"])) for row in rows]
        if not series:
            continue
        color = colors[idx % len(colors)]
        points = scale_points(series, x_min, x_max, y_min, y_max, left, top, plot_width, plot_height)
        lines.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="2.2"/>')
        for x_value, y_value in series:
            point = scale_points([(x_value, y_value)], x_min, x_max, y_min, y_max, left, top, plot_width, plot_height)
            x_str, y_str = point.split(",")
            lines.append(f'<circle cx="{x_str}" cy="{y_str}" r="3" fill="{color}" opacity="0.8"/>')

    lines.append("</svg>")
    path.write_text("\n".join(lines), encoding="utf-8")


def write_report(path: Path, analyses: list[LogAnalysis], summaries: list[dict[str, Any]]) -> None:
    lines = [
        "# Flight Endurance and Power Analysis",
        "",
        "## Method",
        "",
        f"- Effective flight window: longest continuous {BIN_SECONDS:.0f} s-bin run with mean current > {CURRENT_THRESHOLD_A:.1f} A.",
        "- Instantaneous power: `BAT.Volt * BAT.Curr`.",
        "- Power-speed curve: each `BAT` sample is matched to the nearest `GPS.Spd` sample within 1 s.",
        "- Estimated airspeed: GPS ground velocity minus EKF wind estimate from `XKF2.VWN/VWE`; this is not measured airspeed.",
        "- Used capacity: final minus initial `BAT.CurrTot` inside the detected flight window.",
        "- Used energy: final minus initial `BAT.EnrgTot` inside the detected flight window.",
        "",
        "## Summary",
        "",
        "| Log | Battery | Endurance (min) | Capacity used (mAh) | Energy used (Wh) | Mean power (W) | Mean GPS speed (m/s) | Mean est. airspeed (m/s) |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summaries:
        lines.append(
            "| {log} | {battery_capacity_mAh} | {endurance_min:.2f} | {capacity_used_mAh:.1f} | "
            "{energy_used_Wh:.2f} | {power_mean_W:.1f} | {speed_mean_mps:.2f} | {estimated_airspeed_mean_mps:.2f} |".format(**row)
        )

    lines.extend(["", "## Per-log Details", ""])
    for analysis, row in zip(analyses, summaries):
        lines.extend(
            [
                f"### {analysis.log}",
                "",
                f"- Battery capacity label: {analysis.capacity_mah} mAh",
                f"- Flight window: {analysis.flight_start_s:.1f} s to {analysis.flight_end_s:.1f} s",
                f"- Endurance: {row['endurance_min']:.2f} min",
                f"- Capacity used: {row['capacity_used_mAh']:.1f} mAh ({row['capacity_used_ratio'] * 100:.1f}% of nominal capacity)",
                f"- Energy used: {row['energy_used_Wh']:.2f} Wh",
                f"- Average power from samples: {row['power_mean_W']:.1f} W",
                f"- Average power from energy: {row['average_power_from_energy_W']:.1f} W",
                f"- Current min/mean/max: {row['current_min_A']:.2f} / {row['current_mean_A']:.2f} / {row['current_max_A']:.2f} A",
                f"- Voltage min/mean/max: {row['voltage_min_V']:.2f} / {row['voltage_mean_V']:.2f} / {row['voltage_max_V']:.2f} V",
                f"- Power min/mean/max: {row['power_min_W']:.1f} / {row['power_mean_W']:.1f} / {row['power_max_W']:.1f} W",
                f"- GPS ground speed min/mean/max: {row['speed_min_mps']:.2f} / {row['speed_mean_mps']:.2f} / {row['speed_max_mps']:.2f} m/s",
                f"- Estimated airspeed min/mean/max: {row['estimated_airspeed_min_mps']:.2f} / {row['estimated_airspeed_mean_mps']:.2f} / {row['estimated_airspeed_max_mps']:.2f} m/s",
                f"- EKF wind speed mean/max: {row['ekf_wind_mean_mps']:.2f} / {row['ekf_wind_max_mps']:.2f} m/s",
            ]
        )
        if analysis.gps_first_utc and analysis.gps_last_utc:
            bj_first = analysis.gps_first_utc.astimezone(BEIJING_TZ)
            bj_last = analysis.gps_last_utc.astimezone(BEIJING_TZ)
            lines.append(f"- GPS Beijing time span: {bj_first.isoformat()} to {bj_last.isoformat()}")
        notable_messages = [
            msg
            for msg in analysis.messages
            if "Thrust" in msg or "EKF" in msg or "variance" in msg or "PreArm" in msg
        ][:12]
        if notable_messages:
            lines.append("- Notable messages:")
            lines.extend(f"  - {msg}" for msg in notable_messages)
        lines.append("")

    lines.extend(
        [
            "## Generated Files",
            "",
            "- `Flight/Analysis/data/flight_power_summary.csv`",
            "- `Flight/Analysis/data/flight_power_speed_points.csv`",
            "- `Flight/Analysis/data/flight_power_speed_binned.csv`",
            "- `Flight/Analysis/data/flight_power_estimated_airspeed_points.csv`",
            "- `Flight/Analysis/data/flight_power_estimated_airspeed_binned.csv`",
            "- `Flight/Analysis/data/*_battery_full.csv`",
            "- `Flight/Analysis/data/*_battery_flight.csv`",
            "- `Flight/Analysis/figures/flight_power_comparison.svg`",
            "- `Flight/Analysis/figures/flight_power_vs_speed.svg`",
            "- `Flight/Analysis/figures/flight_power_vs_estimated_airspeed.svg`",
            "- `Flight/Analysis/figures/*_flight_power.svg`",
            "",
            "## Airspeed Caveat",
            "",
            "The estimated airspeed curve is reconstructed from GPS ground velocity and EKF wind estimate. It should be used as a trend reference, not as a replacement for measured pitot/static airspeed data.",
            "In the current logs, the aligned `XKF2.VWN/VWE` wind estimates are zero, so estimated airspeed is numerically identical to GPS ground speed.",
            "",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    script_dir = Path(__file__).resolve().parent
    analysis_dir = script_dir.parent
    flight_dir = analysis_dir.parent
    logs_dir = flight_dir / "Logs"
    data_dir = analysis_dir / "data"
    figures_dir = analysis_dir / "figures"
    reports_dir = analysis_dir / "reports"

    for directory in (data_dir, figures_dir, reports_dir):
        directory.mkdir(parents=True, exist_ok=True)

    log_paths = sorted(logs_dir.glob("*.BIN"))
    if not log_paths:
        raise FileNotFoundError(f"No .BIN logs found in {logs_dir}")

    analyses = [analyze_log(path) for path in log_paths]
    summaries = [summarize(analysis) for analysis in analyses]
    all_power_speed_points: list[dict[str, Any]] = []
    all_power_speed_binned: list[dict[str, Any]] = []
    all_power_airspeed_points: list[dict[str, Any]] = []
    all_power_airspeed_binned: list[dict[str, Any]] = []

    for analysis in analyses:
        stem = Path(analysis.log).stem
        points = power_speed_points(analysis, "ground_speed")
        binned = binned_power_speed(analysis, "ground_speed")
        airspeed_points = power_speed_points(analysis, "estimated_airspeed")
        airspeed_binned = binned_power_speed(analysis, "estimated_airspeed")
        all_power_speed_points.extend(points)
        all_power_speed_binned.extend(binned)
        all_power_airspeed_points.extend(airspeed_points)
        all_power_airspeed_binned.extend(airspeed_binned)

        write_battery_csv(data_dir / f"{stem}_battery_full.csv", analysis.full_samples, flight_only=False)
        write_battery_csv(data_dir / f"{stem}_battery_flight.csv", analysis.flight_samples, flight_only=True)
        write_rows_csv(data_dir / f"{stem}_power_speed_points.csv", points)
        write_rows_csv(data_dir / f"{stem}_power_speed_binned.csv", binned)
        write_rows_csv(data_dir / f"{stem}_power_estimated_airspeed_points.csv", airspeed_points)
        write_rows_csv(data_dir / f"{stem}_power_estimated_airspeed_binned.csv", airspeed_binned)
        make_svg_plot(
            figures_dir / f"{stem}_flight_power.svg",
            f"{analysis.log} endurance and power",
            [analysis],
            [
                ("Voltage", "Voltage (V)", lambda s: s.voltage_v),
                ("Current", "Current (A)", lambda s: s.current_a),
                ("Power", "Power (W)", lambda s: s.power_w),
                ("GPS Ground Speed", "Speed (m/s)", lambda s: s.ground_speed_mps),
                ("Estimated Airspeed", "Airspeed (m/s)", lambda s: s.estimated_airspeed_mps),
            ],
        )
        make_power_speed_svg(
            figures_dir / f"{stem}_power_vs_speed.svg",
            f"{analysis.log} power vs GPS ground speed",
            binned,
            "GPS ground speed (m/s)",
        )
        make_power_speed_svg(
            figures_dir / f"{stem}_power_vs_estimated_airspeed.svg",
            f"{analysis.log} power vs estimated airspeed",
            airspeed_binned,
            "Estimated airspeed (m/s)",
        )

    write_summary_csv(data_dir / "flight_power_summary.csv", summaries)
    write_rows_csv(data_dir / "flight_power_speed_points.csv", all_power_speed_points)
    write_rows_csv(data_dir / "flight_power_speed_binned.csv", all_power_speed_binned)
    write_rows_csv(data_dir / "flight_power_estimated_airspeed_points.csv", all_power_airspeed_points)
    write_rows_csv(data_dir / "flight_power_estimated_airspeed_binned.csv", all_power_airspeed_binned)
    make_svg_plot(
        figures_dir / "flight_power_comparison.svg",
        "Flight endurance and power comparison",
        analyses,
        [
            ("Voltage", "Voltage (V)", lambda s: s.voltage_v),
            ("Current", "Current (A)", lambda s: s.current_a),
            ("Power", "Power (W)", lambda s: s.power_w),
            ("GPS Ground Speed", "Speed (m/s)", lambda s: s.ground_speed_mps),
            ("Estimated Airspeed", "Airspeed (m/s)", lambda s: s.estimated_airspeed_mps),
        ],
    )
    make_power_speed_svg(
        figures_dir / "flight_power_vs_speed.svg",
        "Flight power vs GPS ground speed",
        all_power_speed_binned,
        "GPS ground speed (m/s)",
    )
    make_power_speed_svg(
        figures_dir / "flight_power_vs_estimated_airspeed.svg",
        "Flight power vs estimated airspeed",
        all_power_airspeed_binned,
        "Estimated airspeed (m/s)",
    )
    write_report(reports_dir / "flight_power_report.md", analyses, summaries)

    for row in summaries:
        print(
            "{log}: endurance={endurance_min:.2f} min, mean_power={power_mean_W:.1f} W, "
            "mean_gps_speed={speed_mean_mps:.2f} m/s, mean_est_airspeed={estimated_airspeed_mean_mps:.2f} m/s, "
            "energy={energy_used_Wh:.2f} Wh, capacity={capacity_used_mAh:.1f} mAh".format(**row)
        )


if __name__ == "__main__":
    main()
