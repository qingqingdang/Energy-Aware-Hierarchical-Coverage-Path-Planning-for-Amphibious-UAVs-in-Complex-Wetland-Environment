# Flight Analysis Workspace

This folder keeps code and generated analysis outputs separated.

## Directory Layout

- `scripts/`: Python analysis scripts.
- `data/`: Generated CSV files.
- `figures/`: Generated SVG figures.
- `reports/`: Generated Markdown reports.
- `log_inventory.md` and `log_message_inventory.csv`: Message inventory from the earlier log scan.

## Run

From the repository root:

```powershell
D:\anaconda3\envs\markitdown\python.exe Flight\Analysis\scripts\analyze_flight_power.py
```

The script analyzes all `.BIN` files in `Flight/Logs`.

## Current Flight-window Rule

The effective flight segment is detected as the longest continuous run of 5-second bins where mean battery current is above 8 A. This removes standby sections such as the pre-flight idle period in `00000157.BIN`.

## Power-speed Curve

The script matches each battery sample to the nearest `GPS.Spd` sample within 1 second, then computes:

- power: `BAT.Volt * BAT.Curr`
- speed: `GPS.Spd`

It exports raw points and 0.25 m/s speed-bin averages:

- `data/flight_power_speed_points.csv`
- `data/flight_power_speed_binned.csv`
- `figures/flight_power_vs_speed.svg`

## Estimated Airspeed-power Curve

The estimated airspeed curve is reconstructed from GPS ground velocity and EKF wind estimate:

```text
ground_velocity = GPS.Spd + GPS.GCrs
estimated_airspeed_vector = ground_velocity - [XKF2.VWN, XKF2.VWE]
estimated_airspeed = norm(estimated_airspeed_vector)
```

This is an estimated value, not measured pitot/static airspeed.

Outputs:

- `data/flight_power_estimated_airspeed_points.csv`
- `data/flight_power_estimated_airspeed_binned.csv`
- `figures/flight_power_vs_estimated_airspeed.svg`
