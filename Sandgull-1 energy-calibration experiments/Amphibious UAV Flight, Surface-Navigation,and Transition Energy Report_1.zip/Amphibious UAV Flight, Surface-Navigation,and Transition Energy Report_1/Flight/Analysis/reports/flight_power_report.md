# Flight Endurance and Power Analysis

## Method

- Effective flight window: longest continuous 5 s-bin run with mean current > 8.0 A.
- Instantaneous power: `BAT.Volt * BAT.Curr`.
- Power-speed curve: each `BAT` sample is matched to the nearest `GPS.Spd` sample within 1 s.
- Estimated airspeed: GPS ground velocity minus EKF wind estimate from `XKF2.VWN/VWE`; this is not measured airspeed.
- Used capacity: final minus initial `BAT.CurrTot` inside the detected flight window.
- Used energy: final minus initial `BAT.EnrgTot` inside the detected flight window.

## Summary

| Log | Battery | Endurance (min) | Capacity used (mAh) | Energy used (Wh) | Mean power (W) | Mean GPS speed (m/s) | Mean est. airspeed (m/s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| 00000157.BIN | 10000 | 17.58 | 8401.8 | 175.86 | 600.0 | 0.74 | 0.74 |
| 00000158.BIN | 12000 | 18.08 | 9093.3 | 187.27 | 621.3 | 0.57 | 0.57 |
| 00000161.BIN | 12000 | 17.67 | 10079.8 | 196.31 | 666.6 | 0.94 | 0.94 |
| 00000162.BIN | 12000 | 20.50 | 10859.3 | 208.52 | 610.1 | 0.14 | 0.14 |

## Per-log Details

### 00000157.BIN

- Battery capacity label: 10000 mAh
- Flight window: 565.0 s to 1620.0 s
- Endurance: 17.58 min
- Capacity used: 8401.8 mAh (84.0% of nominal capacity)
- Energy used: 175.86 Wh
- Average power from samples: 600.0 W
- Average power from energy: 600.1 W
- Current min/mean/max: 0.25 / 28.67 / 45.39 A
- Voltage min/mean/max: 12.51 / 20.99 / 24.92 V
- Power min/mean/max: 4.3 / 600.0 / 914.3 W
- GPS ground speed min/mean/max: 0.00 / 0.74 / 4.06 m/s
- Estimated airspeed min/mean/max: 0.00 / 0.74 / 4.06 m/s
- EKF wind speed mean/max: 0.00 / 0.00 m/s
- GPS Beijing time span: 2026-07-09T15:59:37+08:00 to 2026-07-09T16:28:09.200000+08:00
- Notable messages:
  - PreArm: Need Position Estimate
  - EKF3 IMU0 yaw aligned to GPS velocity
  - EKF3 IMU1 yaw aligned to GPS velocity
  - EKF3 IMU0 is using GPS
  - EKF3 IMU1 is using GPS
  - Potential Thrust Loss (3)
  - EKF3 IMU0 stopped aiding
  - EKF3 IMU1 stopped aiding
  - EKF variance

### 00000158.BIN

- Battery capacity label: 12000 mAh
- Flight window: 5.0 s to 1090.0 s
- Endurance: 18.08 min
- Capacity used: 9093.3 mAh (75.8% of nominal capacity)
- Energy used: 187.27 Wh
- Average power from samples: 621.3 W
- Average power from energy: 621.4 W
- Current min/mean/max: 0.12 / 30.17 / 48.81 A
- Voltage min/mean/max: 10.60 / 20.63 / 23.95 V
- Power min/mean/max: 1.8 / 621.3 / 891.3 W
- GPS ground speed min/mean/max: 0.00 / 0.57 / 2.83 m/s
- Estimated airspeed min/mean/max: 0.00 / 0.57 / 2.83 m/s
- EKF wind speed mean/max: 0.00 / 0.00 m/s
- GPS Beijing time span: 2026-07-09T16:56:25.400000+08:00 to 2026-07-09T17:14:58.800000+08:00
- Notable messages:
  - EKF3 IMU1 yaw aligned using GPS
  - EKF3 lane switch 1
  - EKF primary changed:1
  - EKF3 IMU1 is using GPS
  - EKF3 IMU0 yaw aligned to GPS velocity
  - EKF3 IMU0 is using GPS
  - Potential Thrust Loss (4)
  - EKF3 IMU0 stopped aiding
  - EKF3 IMU1 stopped aiding
  - EKF primary changed:0
  - EKF variance
  - EKF3 IMU1 yaw aligned using GPS

### 00000161.BIN

- Battery capacity label: 12000 mAh
- Flight window: 5.0 s to 1065.0 s
- Endurance: 17.67 min
- Capacity used: 10079.8 mAh (84.0% of nominal capacity)
- Energy used: 196.31 Wh
- Average power from samples: 666.6 W
- Average power from energy: 666.7 W
- Current min/mean/max: 0.25 / 34.23 / 48.29 A
- Voltage min/mean/max: 9.67 / 19.52 / 24.84 V
- Power min/mean/max: 4.2 / 666.6 / 854.9 W
- GPS ground speed min/mean/max: 0.01 / 0.94 / 3.24 m/s
- Estimated airspeed min/mean/max: 0.01 / 0.94 / 3.24 m/s
- EKF wind speed mean/max: 0.00 / 0.00 m/s
- GPS Beijing time span: 2026-07-10T18:32:38+08:00 to 2026-07-10T18:51:02.800000+08:00
- Notable messages:
  - EKF3 IMU0 yaw aligned using GPS
  - EKF3 IMU1 yaw aligned using GPS
  - EKF3 IMU0 is using GPS
  - EKF3 IMU1 is using GPS
  - Potential Thrust Loss (2)
  - EKF3 IMU0 stopped aiding
  - EKF3 IMU1 stopped aiding
  - EKF variance

### 00000162.BIN

- Battery capacity label: 12000 mAh
- Flight window: 0.0 s to 1230.0 s
- Endurance: 20.50 min
- Capacity used: 10859.3 mAh (90.5% of nominal capacity)
- Energy used: 208.52 Wh
- Average power from samples: 610.1 W
- Average power from energy: 610.3 W
- Current min/mean/max: 2.65 / 31.79 / 46.03 A
- Voltage min/mean/max: 9.30 / 19.24 / 24.87 V
- Power min/mean/max: 35.1 / 610.1 / 828.7 W
- GPS ground speed min/mean/max: 0.00 / 0.14 / 4.12 m/s
- Estimated airspeed min/mean/max: 0.00 / 0.14 / 4.12 m/s
- EKF wind speed mean/max: 0.00 / 0.00 m/s
- GPS Beijing time span: 2026-07-15T18:55:33.600000+08:00 to 2026-07-15T19:19:02.400000+08:00
- Notable messages:
  - EKF3 IMU0 MAG0 ground mag anomaly, yaw re-aligned
  - EKF3 IMU1 MAG0 ground mag anomaly, yaw re-aligned
  - EKF3 IMU0 MAG0 in-flight yaw alignment complete
  - EKF3 IMU1 MAG0 in-flight yaw alignment complete
  - EKF3 IMU0 emergency yaw reset
  - EKF3 IMU1 emergency yaw reset
  - Potential Thrust Loss (3)
  - EKF3 lane switch 1
  - EKF primary changed:1
  - Potential Thrust Loss (1)
  - EKF primary changed:0

## Generated Files

- `Flight/Analysis/data/flight_power_summary.csv`
- `Flight/Analysis/data/flight_power_speed_points.csv`
- `Flight/Analysis/data/flight_power_speed_binned.csv`
- `Flight/Analysis/data/flight_power_estimated_airspeed_points.csv`
- `Flight/Analysis/data/flight_power_estimated_airspeed_binned.csv`
- `Flight/Analysis/data/*_battery_full.csv`
- `Flight/Analysis/data/*_battery_flight.csv`
- `Flight/Analysis/figures/flight_power_comparison.svg`
- `Flight/Analysis/figures/flight_power_vs_speed.svg`
- `Flight/Analysis/figures/flight_power_vs_estimated_airspeed.svg`
- `Flight/Analysis/figures/*_flight_power.svg`

## Airspeed Caveat

The estimated airspeed curve is reconstructed from GPS ground velocity and EKF wind estimate. It should be used as a trend reference, not as a replacement for measured pitot/static airspeed data.
In the current logs, the aligned `XKF2.VWN/VWE` wind estimates are zero, so estimated airspeed is numerically identical to GPS ground speed.
