# Flight Log Inventory

## 00000157.BIN

- Size: 26.57 MB
- Records decoded: 676774
- Message types: 184
- Resync errors: 0
- GPS time: 2026-07-09T07:59:37+00:00 to 2026-07-09T08:28:09.200000+00:00 UTC
- Beijing time: 2026-07-09T15:59:37+00:00 to 2026-07-09T16:28:09.200000+00:00
- Top messages: IMU:87126, SURF:46450, VIBE:34848, XKF4:23232, XKF1:23232, XKF2:23232, XKF3:23232, XKFS:23232, XKQ:23232, XKY0:22848, XKY1:22848, BARO:11619, CTUN:11619, POWR:11618, BAT:11618, DCM:11617, ATT:11616, ANG:11616, RATE:11616, PIDR:11616

### Major Data Categories

- EKF / estimator: 202110 records
- Other: 164893 records
- Sensors / IMU: 121974 records
- PID / control: 46762 records
- GNSS / navigation: 23262 records
- Battery / power: 23236 records
- Attitude: 23232 records
- Attitude control: 23232 records
- RC input/output: 23232 records
- Sensors / barometer: 11619 records
- Control tuning: 11619 records
- Parameters / metadata: 1569 records
- State / messages: 20 records
- State / events: 14 records

### Important Recorded Channels

- BAT: 11618 records; fields: TimeUS, Inst, Volt, VoltR, Curr, CurrTot, EnrgTot, Temp, Res, RemPct, H, SH
- GPS: 5823 records; fields: TimeUS, I, Status, GMS, GWk, NSats, HDop, Lat, Lng, Alt, Spd, GCrs, VZ, Yaw, U
- GPA: 5823 records; fields: TimeUS, I, VDop, HAcc, VAcc, SAcc, YAcc, VV, SMS, Delta, AEl, RTCMFU, RTCMFD
- ATT: 11616 records; fields: TimeUS, DesRoll, Roll, DesPitch, Pitch, DesYaw, Yaw, AEKF
- AHR2: 11616 records; fields: TimeUS, Roll, Pitch, Yaw, Alt, Lat, Lng, Q1, Q2, Q3, Q4
- BARO: 11619 records; fields: TimeUS, I, Alt, AltAMSL, Press, Temp, CRt, SMS, Offset, GndTemp, Health
- IMU: 87126 records; fields: TimeUS, I, GyrX, GyrY, GyrZ, AccX, AccY, AccZ, EG, EA, T, GH, AH, GHz, AHz
- VIBE: 34848 records; fields: TimeUS, IMU, VibeX, VibeY, VibeZ, Clip
- RCIN: 11616 records; fields: TimeUS, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14
- RCOU: 11616 records; fields: TimeUS, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14
- MODE: 2 records; fields: TimeUS, Mode, ModeNum, Rsn
- ARM: 1 records; fields: TimeUS, ArmState, ArmChecks, Forced, Method
- ERR: 3 records; fields: TimeUS, Subsys, ECode
- EV: 8 records; fields: TimeUS, Id
- CTUN: 11619 records; fields: TimeUS, ThI, ABst, ThO, ThH, DAlt, Alt, BAlt, DSAlt, SAlt, TAlt, DCRt, CRt
- POS: 11616 records; fields: TimeUS, Lat, Lng, Alt, RelHomeAlt, RelOriginAlt
- MSG: 20 records; fields: TimeUS, Message
- VER: 1 records; fields: TimeUS, BT, BST, Maj, Min, Pat, FWT, GH, FWS, APJ, BU, FV
- PARM: 1141 records; fields: TimeUS, Name, Value, Default

### First MSG Text Entries

- ArduCopter V4.6.2 (1ebd4d99)
- ChibiOS: 88b84600
- CUAVv5 001E0030 30335107 32343834
- Param space used: 1337/5376
- RC Protocol: SBUS
- RCOut: PWM:1-16
- New mission
- New rally
- New fence
- Frame: QUAD/X
- GPS 1: specified as DroneCAN1-123
- PreArm: Need Position Estimate
- EKF3 IMU0 yaw aligned to GPS velocity
- EKF3 IMU1 yaw aligned to GPS velocity
- EKF3 IMU0 is using GPS
- EKF3 IMU1 is using GPS
- Potential Thrust Loss (3)
- EKF3 IMU0 stopped aiding
- EKF3 IMU1 stopped aiding
- EKF variance

### Sample Values

- BAT: TimeUS=57462815, Inst=0, Volt=25, VoltR=25, Curr=0.0232, CurrTot=0.1398, EnrgTot=0.003498, Temp=0, Res=0.3088, RemPct=99
- GPS: TimeUS=57590983, I=0, Status=3, GMS=374395000, GWk=2426, NSats=29, HDop=0.52, Lat=31.49, Lng=121.2, Alt=3.9
- GPA: TimeUS=57590983, I=0, VDop=0.91, HAcc=0.83, VAcc=1.51, SAcc=0.22, YAcc=0, VV=1, SMS=57545, Delta=200
- ATT: TimeUS=57463366, DesRoll=0, Roll=0.605, DesPitch=0, Pitch=0.289, DesYaw=0.1568, Yaw=360, AEKF=3
- AHR2: TimeUS=57463862, Roll=0.6, Pitch=0.24, Yaw=359.8, Alt=3.32, Lat=31.49, Lng=121.2, Q1=1, Q2=0.005327, Q3=0.0021
- BARO: TimeUS=57462984, I=0, Alt=0.04439, AltAMSL=3.434, Press=1.006e+05, Temp=43.2, CRt=-0.008279, SMS=57462, Offset=0, GndTemp=35
- IMU: TimeUS=57484642, I=0, GyrX=0.0004717, GyrY=-0.0006432, GyrZ=0.0006282, AccX=0.01606, AccY=-0.1255, AccZ=-9.798, EG=0, EA=0
- VIBE: TimeUS=57464211, IMU=0, VibeX=0.03812, VibeY=0.134, VibeZ=0.04197, Clip=0
- RCIN: TimeUS=57463960, C1=1495, C2=1495, C3=1045, C4=1639, C5=1495, C6=1495, C7=1495, C8=1490, C9=1495
- RCOU: TimeUS=57463994, C1=1000, C2=1000, C3=1000, C4=1000, C5=0, C6=0, C7=0, C8=0, C9=1495
- MODE: TimeUS=57714569, Mode=16, ModeNum=16, Rsn=1
- ARM: TimeUS=1754823591, ArmState=0, ArmChecks=0, Forced=0, Method=17
- ERR: TimeUS=1672844842, Subsys=25, ECode=1
- EV: TimeUS=621169385, Id=15
- CTUN: TimeUS=57463041, ThI=0, ABst=0, ThO=0, ThH=0.5492, DAlt=0.4636, Alt=0.4636, BAlt=0.04, DSAlt=nan, SAlt=0
- POS: TimeUS=57463874, Lat=31.49, Lng=121.2, Alt=3.92, RelHomeAlt=0.4636, RelOriginAlt=0.4636
- MSG: TimeUS=57712920, Message=ArduCopter V4.6.2 (1ebd4d99)
- VER: TimeUS=57712945, BT=10, BST=5013, Maj=4, Min=6, Pat=2, FWT=255, GH=515722649, FWS=ArduCopter V4.6.2 (1ebd4d99), APJ=50
- PARM: TimeUS=57466359, Name=FORMAT_VERSION, Value=120, Default=120


## 00000158.BIN

- Size: 25.42 MB
- Records decoded: 647515
- Message types: 183
- Resync errors: 0
- GPS time: 2026-07-09T08:56:25.400000+00:00 to 2026-07-09T09:14:58.800000+00:00 UTC
- Beijing time: 2026-07-09T16:56:25.400000+00:00 to 2026-07-09T17:14:58.800000+00:00
- Top messages: IMU:83358, SURF:44446, VIBE:33342, XKF4:22228, XKF1:22228, XKF2:22228, XKF3:22228, XKFS:22228, XKQ:22228, XKY0:22221, XKY1:22221, BARO:11116, CTUN:11116, POWR:11116, BAT:11116, DCM:11115, EAHR:11115, ATT:11114, ANG:11114, RATE:11114

### Major Data Categories

- EKF / estimator: 193966 records
- Other: 156776 records
- Sensors / IMU: 116700 records
- PID / control: 44456 records
- GNSS / navigation: 22250 records
- Battery / power: 22232 records
- Attitude: 22228 records
- Attitude control: 22228 records
- RC input/output: 22228 records
- Sensors / barometer: 11116 records
- Control tuning: 11116 records
- Parameters / metadata: 1591 records
- State / messages: 556 records
- State / events: 72 records

### Important Recorded Channels

- BAT: 11116 records; fields: TimeUS, Inst, Volt, VoltR, Curr, CurrTot, EnrgTot, Temp, Res, RemPct, H, SH
- GPS: 5568 records; fields: TimeUS, I, Status, GMS, GWk, NSats, HDop, Lat, Lng, Alt, Spd, GCrs, VZ, Yaw, U
- GPA: 5568 records; fields: TimeUS, I, VDop, HAcc, VAcc, SAcc, YAcc, VV, SMS, Delta, AEl, RTCMFU, RTCMFD
- ATT: 11114 records; fields: TimeUS, DesRoll, Roll, DesPitch, Pitch, DesYaw, Yaw, AEKF
- AHR2: 11114 records; fields: TimeUS, Roll, Pitch, Yaw, Alt, Lat, Lng, Q1, Q2, Q3, Q4
- BARO: 11116 records; fields: TimeUS, I, Alt, AltAMSL, Press, Temp, CRt, SMS, Offset, GndTemp, Health
- IMU: 83358 records; fields: TimeUS, I, GyrX, GyrY, GyrZ, AccX, AccY, AccZ, EG, EA, T, GH, AH, GHz, AHz
- VIBE: 33342 records; fields: TimeUS, IMU, VibeX, VibeY, VibeZ, Clip
- RCIN: 11114 records; fields: TimeUS, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14
- RCOU: 11114 records; fields: TimeUS, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14
- MODE: 2 records; fields: TimeUS, Mode, ModeNum, Rsn
- ARM: 1 records; fields: TimeUS, ArmState, ArmChecks, Forced, Method
- ERR: 5 records; fields: TimeUS, Subsys, ECode
- EV: 64 records; fields: TimeUS, Id
- CTUN: 11116 records; fields: TimeUS, ThI, ABst, ThO, ThH, DAlt, Alt, BAlt, DSAlt, SAlt, TAlt, DCRt, CRt
- POS: 11114 records; fields: TimeUS, Lat, Lng, Alt, RelHomeAlt, RelOriginAlt
- MSG: 556 records; fields: TimeUS, Message
- VER: 1 records; fields: TimeUS, BT, BST, Maj, Min, Pat, FWT, GH, FWS, APJ, BU, FV
- PARM: 1141 records; fields: TimeUS, Name, Value, Default

### First MSG Text Entries

- ArduCopter V4.6.2 (1ebd4d99)
- ChibiOS: 88b84600
- CUAVv5 001E0030 30335107 32343834
- Param space used: 1369/5376
- RC Protocol: SBUS
- RCOut: PWM:1-16
- New mission
- New rally
- New fence
- Frame: QUAD/X
- GPS 1: specified as DroneCAN1-123
- EKF3 IMU1 yaw aligned using GPS
- EKF3 lane switch 1
- EKF primary changed:1
- EKF3 IMU1 is using GPS
- EKF3 IMU0 yaw aligned to GPS velocity
- EKF3 IMU0 is using GPS
- Potential Thrust Loss (4)
- EKF3 IMU0 stopped aiding
- EKF3 IMU1 stopped aiding
- EKF primary changed:0
- EKF variance
- EKF3 IMU1 yaw aligned using GPS
- EKF3 IMU1 is using GPS
- EKF3 IMU1 stopped aiding
- EKF3 IMU1 yaw aligned using GPS
- EKF3 IMU1 is using GPS
- EKF3 IMU1 stopped aiding
- EKF3 IMU1 yaw aligned using GPS
- EKF3 IMU1 is using GPS

### Sample Values

- BAT: TimeUS=165603832, Inst=0, Volt=24.17, VoltR=24.26, Curr=0, CurrTot=0.03447, EnrgTot=0.0008328, Temp=0, Res=1.054, RemPct=99
- GPS: TimeUS=165536537, I=0, Status=3, GMS=377803400, GWk=2426, NSats=26, HDop=0.58, Lat=31.49, Lng=121.2, Alt=1.34
- GPA: TimeUS=165536537, I=0, VDop=0.91, HAcc=0.68, VAcc=1, SAcc=0.2, YAcc=0, VV=1, SMS=165504, Delta=200
- ATT: TimeUS=165494967, DesRoll=-3.786e-14, Roll=0.7415, DesPitch=1.022e-13, Pitch=0.1734, DesYaw=117.6, Yaw=112.5, AEKF=3
- AHR2: TimeUS=165495928, Roll=0.44, Pitch=0.53, Yaw=196.6, Alt=0.52, Lat=31.49, Lng=121.2, Q1=-0.1442, Q2=-0.005177, Q3=0.003186
- BARO: TimeUS=165494292, I=0, Alt=-0.8303, AltAMSL=1.15, Press=1.005e+05, Temp=38.38, CRt=0.1567, SMS=165494, Offset=0, GndTemp=35
- IMU: TimeUS=165514490, I=0, GyrX=0.000925, GyrY=-6.694e-05, GyrZ=0.000324, AccX=-0.001818, AccY=-0.1518, AccZ=-9.791, EG=0, EA=0
- VIBE: TimeUS=165496480, IMU=0, VibeX=0.07259, VibeY=0.0508, VibeZ=0.02496, Clip=0
- RCIN: TimeUS=165496069, C1=1495, C2=1495, C3=1074, C4=1945, C5=1045, C6=1495, C7=1495, C8=1490, C9=1495
- RCOU: TimeUS=165496262, C1=1000, C2=1000, C3=1000, C4=1000, C5=0, C6=0, C7=0, C8=0, C9=1495
- MODE: TimeUS=165493004, Mode=2, ModeNum=2, Rsn=1
- ARM: TimeUS=1264079407, ArmState=0, ArmChecks=0, Forced=0, Method=17
- ERR: TimeUS=175744565, Subsys=24, ECode=1
- EV: TimeUS=166121185, Id=15
- CTUN: TimeUS=165494462, ThI=-5.007e-06, ABst=-4.425e-10, ThO=0, ThH=0.6518, DAlt=-0.5621, Alt=-0.5621, BAlt=-0.83, DSAlt=nan, SAlt=0
- POS: TimeUS=165496002, Lat=31.49, Lng=121.2, Alt=1.33, RelHomeAlt=0.08793, RelOriginAlt=-0.5621
- MSG: TimeUS=165751678, Message=ArduCopter V4.6.2 (1ebd4d99)
- VER: TimeUS=165751701, BT=10, BST=5013, Maj=4, Min=6, Pat=2, FWT=255, GH=515722649, FWS=ArduCopter V4.6.2 (1ebd4d99), APJ=50
- PARM: TimeUS=165504487, Name=FORMAT_VERSION, Value=120, Default=120


## 00000161.BIN

- Size: 25.29 MB
- Records decoded: 644063
- Message types: 185
- Resync errors: 0
- GPS time: 2026-07-10T10:32:38+00:00 to 2026-07-10T10:51:02.800000+00:00 UTC
- Beijing time: 2026-07-10T18:32:38+00:00 to 2026-07-10T18:51:02.800000+00:00
- Top messages: IMU:82827, SURF:44176, VIBE:33132, XKF4:22088, XKF1:22088, XKF2:22088, XKF3:22088, XKFS:22088, XKQ:22088, XKY0:22082, XKY1:22082, BARO:11044, CTUN:11044, ATT:11044, ANG:11044, RATE:11044, PIDR:11044, PIDP:11044, PIDY:11044, PIDA:11044

### Major Data Categories

- EKF / estimator: 192778 records
- Other: 156979 records
- Sensors / IMU: 115959 records
- PID / control: 44176 records
- GNSS / navigation: 22094 records
- Attitude: 22088 records
- Attitude control: 22088 records
- RC input/output: 22088 records
- Battery / power: 22088 records
- Sensors / barometer: 11044 records
- Control tuning: 11044 records
- Parameters / metadata: 1595 records
- State / events: 22 records
- State / messages: 20 records

### Important Recorded Channels

- BAT: 11044 records; fields: TimeUS, Inst, Volt, VoltR, Curr, CurrTot, EnrgTot, Temp, Res, RemPct, H, SH
- GPS: 5525 records; fields: TimeUS, I, Status, GMS, GWk, NSats, HDop, Lat, Lng, Alt, Spd, GCrs, VZ, Yaw, U
- GPA: 5525 records; fields: TimeUS, I, VDop, HAcc, VAcc, SAcc, YAcc, VV, SMS, Delta, AEl, RTCMFU, RTCMFD
- ATT: 11044 records; fields: TimeUS, DesRoll, Roll, DesPitch, Pitch, DesYaw, Yaw, AEKF
- AHR2: 11044 records; fields: TimeUS, Roll, Pitch, Yaw, Alt, Lat, Lng, Q1, Q2, Q3, Q4
- BARO: 11044 records; fields: TimeUS, I, Alt, AltAMSL, Press, Temp, CRt, SMS, Offset, GndTemp, Health
- IMU: 82827 records; fields: TimeUS, I, GyrX, GyrY, GyrZ, AccX, AccY, AccZ, EG, EA, T, GH, AH, GHz, AHz
- VIBE: 33132 records; fields: TimeUS, IMU, VibeX, VibeY, VibeZ, Clip
- RCIN: 11044 records; fields: TimeUS, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14
- RCOU: 11044 records; fields: TimeUS, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14
- MODE: 3 records; fields: TimeUS, Mode, ModeNum, Rsn
- ARM: 3 records; fields: TimeUS, ArmState, ArmChecks, Forced, Method
- ERR: 3 records; fields: TimeUS, Subsys, ECode
- EV: 13 records; fields: TimeUS, Id
- CTUN: 11044 records; fields: TimeUS, ThI, ABst, ThO, ThH, DAlt, Alt, BAlt, DSAlt, SAlt, TAlt, DCRt, CRt
- POS: 11044 records; fields: TimeUS, Lat, Lng, Alt, RelHomeAlt, RelOriginAlt
- MSG: 20 records; fields: TimeUS, Message
- VER: 1 records; fields: TimeUS, BT, BST, Maj, Min, Pat, FWT, GH, FWS, APJ, BU, FV
- PARM: 1139 records; fields: TimeUS, Name, Value, Default

### First MSG Text Entries

- ArduCopter V4.6.2 (1ebd4d99)
- ChibiOS: 88b84600
- CUAVv5 001E0030 30335107 32343834
- Param space used: 1369/5376
- RC Protocol: SBUS
- RCOut: PWM:1-16
- New mission
- New rally
- New fence
- Frame: QUAD/X
- GPS 1: specified as DroneCAN1-123
- EKF3 IMU0 yaw aligned using GPS
- EKF3 IMU1 yaw aligned using GPS
- EKF3 IMU0 is using GPS
- EKF3 IMU1 is using GPS
- Potential Thrust Loss (2)
- EKF3 IMU0 stopped aiding
- EKF3 IMU1 stopped aiding
- EKF variance
- SmartRTL deactivated: bad position

### Sample Values

- BAT: TimeUS=154442779, Inst=0, Volt=24.93, VoltR=25, Curr=0, CurrTot=0.03737, EnrgTot=0.0009309, Temp=0, Res=0.92, RemPct=99
- GPS: TimeUS=154423845, I=0, Status=4, GMS=469976000, GWk=2426, NSats=28, HDop=0.58, Lat=31.49, Lng=121.2, Alt=2.98
- GPA: TimeUS=154423845, I=0, VDop=0.93, HAcc=0.42, VAcc=0.73, SAcc=0.18, YAcc=0, VV=1, SMS=154381, Delta=200
- ATT: TimeUS=154338405, DesRoll=0, Roll=-0.5551, DesPitch=0, Pitch=0.4805, DesYaw=5.184, Yaw=0.07033, AEKF=3
- AHR2: TimeUS=154339393, Roll=-0.86, Pitch=1.1, Yaw=3.39, Alt=2.67, Lat=31.49, Lng=121.2, Q1=0.9995, Q2=-0.007812, Q3=0.009445
- BARO: TimeUS=154338148, I=0, Alt=-0.3134, AltAMSL=8.207, Press=1.006e+05, Temp=34.06, CRt=0.1382, SMS=154338, Offset=0, GndTemp=32.94
- IMU: TimeUS=154341482, I=0, GyrX=0.0008879, GyrY=-0.0005656, GyrZ=0.001365, AccX=0.04985, AccY=0.06593, AccZ=-9.797, EG=0, EA=0
- VIBE: TimeUS=154339833, IMU=0, VibeX=0.0186, VibeY=0.02076, VibeZ=0.01882, Clip=0
- RCIN: TimeUS=154339581, C1=1501, C2=1501, C3=1051, C4=1951, C5=1051, C6=1051, C7=1101, C8=1051, C9=1051
- RCOU: TimeUS=154339709, C1=1000, C2=1000, C3=1000, C4=1000, C5=0, C6=0, C7=0, C8=0, C9=1051
- MODE: TimeUS=154336289, Mode=2, ModeNum=2, Rsn=1
- ARM: TimeUS=1228219322, ArmState=0, ArmChecks=0, Forced=0, Method=17
- ERR: TimeUS=1212718672, Subsys=25, ECode=1
- EV: TimeUS=156337884, Id=57
- CTUN: TimeUS=154338254, ThI=-7.153e-07, ABst=-5.878e-11, ThO=0, ThH=0.6447, DAlt=-0.2958, Alt=-0.2958, BAlt=-0.31, DSAlt=nan, SAlt=0
- POS: TimeUS=154339475, Lat=31.49, Lng=121.2, Alt=2.99, RelHomeAlt=5.234, RelOriginAlt=-0.2958
- MSG: TimeUS=154597547, Message=ArduCopter V4.6.2 (1ebd4d99)
- VER: TimeUS=154597570, BT=10, BST=5013, Maj=4, Min=6, Pat=2, FWT=255, GH=515722649, FWS=ArduCopter V4.6.2 (1ebd4d99), APJ=50
- PARM: TimeUS=154347817, Name=FORMAT_VERSION, Value=120, Default=120

