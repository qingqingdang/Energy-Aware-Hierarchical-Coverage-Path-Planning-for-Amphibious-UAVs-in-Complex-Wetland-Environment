# Navigation Endurance and Power Analysis

## Method

- Effective navigation window: `ARM` state from armed to disarmed.
- Instantaneous power: `BAT.Volt * BAT.Curr`.
- Speed-power curve: nearest valid `GPS.Spd` within 1.0 s of each `BAT` record. Curve points require `BAT.Curr >= 0.05 A` and a forward propulsion command.
- Forward command: `RCOU.C1/C2` are configured as left/right throttle outputs, both at least 20 us above `SERVO1/2_TRIM`, with a left-right offset difference no greater than 80 us.
- Used capacity: final minus initial `BAT.CurrTot` inside the active window.
- Used energy: final minus initial `BAT.EnrgTot` inside the active window.

## Summary

| Log | Battery | Endurance (min) | Capacity used (mAh) | Energy used (Wh) | Mean power (W) | Forward curve samples | Mean forward speed (m/s) | Mean ThrOut |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 00000131.BIN | 12000 | 47.09 | 156.6 | 3.92 | 4.99 | 0 | nan | 13.58 |
| 00000133.BIN | 12000 | 12.19 | 104.5 | 2.56 | 12.58 | 3174 | 0.87 | 15.50 |

## Per-log Details

### 00000131.BIN

- Battery capacity label: 12000 mAh
- Active window: 46.6 s to 2872.0 s
- Endurance: 47.09 min
- Capacity used: 156.6 mAh (1.3% of nominal capacity)
- Energy used: 3.92 Wh
- Average power from samples: 4.99 W
- Average power from energy: 4.99 W
- Current min/mean/max: 0.000 / 0.200 / 0.557 A
- Voltage min/mean/max: 24.90 / 25.03 / 25.16 V
- Power min/mean/max: 0.00 / 4.99 / 13.90 W
- ThrOut min/mean/max: -88.00 / 13.58 / 97.00
- Forward curve samples: 0
- Speed-power curve: unavailable because no valid forward GPS-speed and propulsion-output samples were found.
- Forward-output mapping supported: False
- GPS samples: none recorded in this log.
- Notable messages:
  - Throttle armed
  - Throttle disarmed
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - Throttle armed
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data
  - EKF3 waiting for GPS config data

### 00000133.BIN

- Battery capacity label: 12000 mAh
- Active window: 0.0 s to 731.1 s
- Endurance: 12.19 min
- Capacity used: 104.5 mAh (0.9% of nominal capacity)
- Energy used: 2.56 Wh
- Average power from samples: 12.58 W
- Average power from energy: 12.59 W
- Current min/mean/max: 0.000 / 0.514 / 5.791 A
- Voltage min/mean/max: 21.87 / 24.55 / 24.67 V
- Power min/mean/max: 0.00 / 12.58 / 137.82 W
- ThrOut min/mean/max: -98.00 / 15.50 / 100.00
- Forward curve samples: 3174
- Speed min/mean/max: 0.02 / 0.87 / 1.27 m/s
- Speed source samples: GPS.Spd=3174, THR.Speed fallback=0
- Forward-output mapping supported: True
- GPS Beijing time span: 2026-07-15T17:08:49.600000+08:00 to 2026-07-15T17:21:00.600000+08:00
- Notable messages:
  - Throttle armed
  - GPS 1: specified as DroneCAN1-124

## Notes

- The recorded battery current is very low for a propulsion test, with mean current below 1 A. If the propulsion system should draw much more, verify the current sensor calibration and whether the logged `BAT` instance measures the whole vehicle power bus.
- GPS speed is ground speed. Current, wind, and sideslip effects are not removed, so the curve should be interpreted as ground-speed power rather than through-water speed power.
- A speed-power point is kept only when a finite GPS.Spd record occurs within 1.0 s of the BAT record, both left/right propulsion outputs indicate forward motion, and battery current is at least 0.05 A. The complete active-sample CSV retains excluded points and their `motion_state` for review.

## Generated Files

- `Navigation/Analysis/data/navigation_power_summary.csv`
- `Navigation/Analysis/data/navigation_power_speed_points.csv`
- `Navigation/Analysis/data/navigation_power_speed_binned.csv`
- `Navigation/Analysis/data/*_navigation_full.csv`
- `Navigation/Analysis/data/*_navigation_active.csv`
- `Navigation/Analysis/figures/navigation_power.svg`
- `Navigation/Analysis/figures/navigation_power_vs_speed.svg`
