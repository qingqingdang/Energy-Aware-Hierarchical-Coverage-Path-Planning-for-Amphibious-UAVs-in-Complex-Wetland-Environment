"""Analyze endurance and power from ArduPilot DataFlash navigation logs.

Outputs are kept under Navigation/Analysis:
  data/    CSV time series and summary tables
  figures/ SVG plots generated with the Python standard library
  reports/ Markdown report
"""

from __future__ import annotations

import csv
import datetime as dt
import html
import math
import statistics
import struct
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


MAGIC = b"\xa3\x95"
GPS_UTC_LEAP_SECONDS = 18
BEIJING_TZ = dt.timezone(dt.timedelta(hours=8))
SPEED_BIN_MPS = 0.1
GPS_MATCH_MAX_S = 1.0
OUTPUT_MATCH_MAX_S = 0.2
MIN_CURVE_CURRENT_A = 0.05
FORWARD_OUTPUT_MIN_DELTA_US = 20.0
FORWARD_OUTPUT_MAX_DIFFERENCE_US = 80.0
THROTTLE_LEFT_FUNCTION = 73
THROTTLE_RIGHT_FUNCTION = 74
BATTERY_CAPACITY_MAH = {
    "00000131": 12000,
    "00000133": 12000,
}

FMT_DEF = {
    "name": "FMT",
    "len": 89,
    "fmt": "BBnNZ",
    "cols": ["Type", "Length", "Name", "Format", "Columns"],
}

FMT_CHARS = {
    "b": ("b", 1),
    "B": ("B", 1),
    "h": ("h", 2),
    "H": ("H", 2),
    "i": ("i", 4),
    "I": ("I", 4),
    "q": ("q", 8),
    "Q": ("Q", 8),
    "f": ("f", 4),
    "d": ("d", 8),
    "n": ("4s", 4),
    "N": ("16s", 16),
    "Z": ("64s", 64),
    "c": ("h", 2),
    "C": ("H", 2),
    "e": ("i", 4),
    "E": ("I", 4),
    "L": ("i", 4),
    "M": ("B", 1),
}

TEXT_FORMATS = {"n", "N", "Z"}


@dataclass
class NavSample:
    log: str
    time_us: int
    time_s: float
    voltage_v: float = math.nan
    resting_voltage_v: float = math.nan
    current_a: float = math.nan
    power_w: float = math.nan
    capacity_used_mah: float = math.nan
    energy_used_wh: float = math.nan
    remaining_percent: float = math.nan
    thr_in: float = math.nan
    thr_out: float = math.nan
    desired_speed: float = math.nan
    speed: float = math.nan
    speed_source: str = ""
    gps_time_offset_s: float = math.nan
    left_output_us: float = math.nan
    right_output_us: float = math.nan
    motion_state: str = "unknown"
    accel_x: float = math.nan
    navigation_time_s: float | None = None


@dataclass
class NavigationAnalysis:
    log: str
    capacity_mah: int
    full_samples: list[NavSample]
    active_samples: list[NavSample]
    active_start_s: float
    active_end_s: float
    parameters: dict[str, float]
    output_mapping_supported: bool
    arm_events: list[dict[str, Any]]
    mode_events: list[dict[str, Any]]
    messages: list[str]
    gps_first_utc: dt.datetime | None
    gps_last_utc: dt.datetime | None
    record_counts: Counter[str]


def parse_c_string(raw: bytes) -> str:
    return raw.split(b"\0", 1)[0].decode("utf-8", "replace")


def decode_payload(fmt: str, cols: list[str], payload: bytes) -> dict[str, Any] | None:
    values: list[Any] = []
    offset = 0
    for char in fmt:
        if char not in FMT_CHARS:
            return None
        struct_fmt, size = FMT_CHARS[char]
        part = payload[offset : offset + size]
        offset += size
        if len(part) != size:
            return None
        if char in TEXT_FORMATS:
            value = parse_c_string(part)
        else:
            value = struct.unpack("<" + struct_fmt, part)[0]
        if char in "cCeE":
            value *= 0.01
        elif char == "L":
            value *= 1e-7
        values.append(value)
    return dict(zip(cols, values))


def gps_to_utc(gps_week: int, gps_millis: float) -> dt.datetime:
    return (
        dt.datetime(1980, 1, 6, tzinfo=dt.timezone.utc)
        + dt.timedelta(weeks=int(gps_week), milliseconds=float(gps_millis))
        - dt.timedelta(seconds=GPS_UTC_LEAP_SECONDS)
    )


def parse_log(path: Path) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
    dict[str, float],
    list[str],
    dt.datetime | None,
    dt.datetime | None,
    Counter[str],
]:
    data = path.read_bytes()
    defs: dict[int, dict[str, Any]] = {128: FMT_DEF.copy()}
    counts: Counter[str] = Counter()
    bat_records: list[dict[str, Any]] = []
    thr_records: list[dict[str, Any]] = []
    gps_records: list[dict[str, Any]] = []
    rcou_records: list[dict[str, Any]] = []
    parameters: dict[str, float] = {}
    arm_events: list[dict[str, Any]] = []
    mode_events: list[dict[str, Any]] = []
    messages: list[str] = []
    gps_first_utc: dt.datetime | None = None
    gps_last_utc: dt.datetime | None = None
    first_time_us: int | None = None
    pos = 0

    while pos + 3 <= len(data):
        if data[pos : pos + 2] != MAGIC:
            next_pos = data.find(MAGIC, pos + 1)
            if next_pos < 0:
                break
            pos = next_pos
            continue

        msg_type = data[pos + 2]
        msg_def = defs.get(msg_type)
        if msg_def is None:
            next_pos = data.find(MAGIC, pos + 1)
            if next_pos < 0:
                break
            pos = next_pos
            continue

        total_len = int(msg_def["len"])
        if total_len < 3 or pos + total_len > len(data):
            break

        payload = data[pos + 3 : pos + total_len]
        name = str(msg_def["name"])
        counts[name] += 1
        rec = decode_payload(str(msg_def["fmt"]), list(msg_def["cols"]), payload)

        if name == "FMT" and rec:
            defs[int(rec["Type"])] = {
                "name": rec["Name"],
                "len": int(rec["Length"]),
                "fmt": rec["Format"],
                "cols": [item for item in str(rec.get("Columns", "")).split(",") if item],
            }
        elif rec:
            time_us = rec.get("TimeUS")
            if isinstance(time_us, int) and first_time_us is None:
                first_time_us = time_us
            if first_time_us is not None and isinstance(time_us, int):
                rec["_time_s"] = (time_us - first_time_us) / 1_000_000

            if name == "BAT" and int(rec.get("Inst", 0)) == 0:
                bat_records.append(rec)
            elif name == "THR":
                thr_records.append(rec)
            elif name == "RCOU":
                rcou_records.append(rec)
            elif name == "PARM":
                parameter_name = str(rec.get("Name", ""))
                parameter_value = rec.get("Value")
                if parameter_name and isinstance(parameter_value, (int, float)):
                    parameters[parameter_name] = float(parameter_value)
            elif name == "ARM":
                arm_events.append(rec)
            elif name == "MODE":
                mode_events.append(rec)
            elif name == "MSG":
                msg = str(rec.get("Message", ""))
                if msg:
                    messages.append(msg)
            elif name == "GPS":
                if isinstance(rec.get("TimeUS"), int):
                    gps_records.append(rec)
                if rec.get("GWk") is not None and rec.get("GMS") is not None:
                    gps_time = gps_to_utc(int(rec["GWk"]), float(rec["GMS"]))
                    gps_first_utc = gps_first_utc or gps_time
                    gps_last_utc = gps_time

        pos += total_len

    return (
        bat_records,
        thr_records,
        gps_records,
        rcou_records,
        parameters,
        arm_events,
        mode_events,
        messages,
        gps_first_utc,
        gps_last_utc,
        counts,
    )


def nearest_thr_record(thr_records: list[dict[str, Any]], time_us: int, start_index: int) -> tuple[dict[str, Any] | None, int]:
    if not thr_records:
        return None, start_index
    index = min(start_index, len(thr_records) - 1)
    while index + 1 < len(thr_records) and abs(thr_records[index + 1]["TimeUS"] - time_us) <= abs(thr_records[index]["TimeUS"] - time_us):
        index += 1
    return thr_records[index], index


def nearest_gps_record(
    gps_records: list[dict[str, Any]], time_us: int, start_index: int
) -> tuple[dict[str, Any] | None, int]:
    if not gps_records:
        return None, start_index
    index = min(start_index, len(gps_records) - 1)
    while (
        index + 1 < len(gps_records)
        and abs(int(gps_records[index + 1]["TimeUS"]) - time_us)
        <= abs(int(gps_records[index]["TimeUS"]) - time_us)
    ):
        index += 1
    record = gps_records[index]
    speed = float(record.get("Spd", math.nan))
    if (
        not math.isfinite(speed)
        or abs(int(record["TimeUS"]) - time_us) > GPS_MATCH_MAX_S * 1_000_000
    ):
        return None, index
    return record, index


def nearest_output_record(
    output_records: list[dict[str, Any]], time_us: int, start_index: int
) -> tuple[dict[str, Any] | None, int]:
    if not output_records:
        return None, start_index
    index = min(start_index, len(output_records) - 1)
    while (
        index + 1 < len(output_records)
        and abs(int(output_records[index + 1]["TimeUS"]) - time_us)
        <= abs(int(output_records[index]["TimeUS"]) - time_us)
    ):
        index += 1
    record = output_records[index]
    if abs(int(record["TimeUS"]) - time_us) > OUTPUT_MATCH_MAX_S * 1_000_000:
        return None, index
    return record, index


def is_powered_navigation_sample(current_a: float) -> bool:
    return math.isfinite(current_a) and current_a >= MIN_CURVE_CURRENT_A


def is_supported_output_mapping(parameters: dict[str, float]) -> bool:
    return (
        int(parameters.get("SERVO1_FUNCTION", -1)) == THROTTLE_LEFT_FUNCTION
        and int(parameters.get("SERVO2_FUNCTION", -1)) == THROTTLE_RIGHT_FUNCTION
        and int(parameters.get("SERVO1_REVERSED", -1)) == 0
        and int(parameters.get("SERVO2_REVERSED", -1)) == 0
    )


def is_forward_navigation_command(
    left_output_us: float,
    right_output_us: float,
    left_trim_us: float,
    right_trim_us: float,
) -> bool:
    left_delta = left_output_us - left_trim_us
    right_delta = right_output_us - right_trim_us
    return (
        left_delta >= FORWARD_OUTPUT_MIN_DELTA_US
        and right_delta >= FORWARD_OUTPUT_MIN_DELTA_US
        and abs(left_delta - right_delta) <= FORWARD_OUTPUT_MAX_DIFFERENCE_US
    )


def combine_samples(
    path: Path,
    bat_records: list[dict[str, Any]],
    thr_records: list[dict[str, Any]],
    gps_records: list[dict[str, Any]],
    output_records: list[dict[str, Any]],
    parameters: dict[str, float],
) -> list[NavSample]:
    samples: list[NavSample] = []
    thr_index = 0
    gps_index = 0
    output_index = 0
    output_mapping_supported = is_supported_output_mapping(parameters)
    left_trim_us = parameters.get("SERVO1_TRIM", math.nan)
    right_trim_us = parameters.get("SERVO2_TRIM", math.nan)
    for rec in bat_records:
        voltage = float(rec.get("Volt", math.nan))
        current = float(rec.get("Curr", math.nan))
        thr_rec, thr_index = nearest_thr_record(thr_records, int(rec["TimeUS"]), thr_index)
        sample = NavSample(
            log=path.name,
            time_us=int(rec["TimeUS"]),
            time_s=float(rec.get("_time_s", math.nan)),
            voltage_v=voltage,
            resting_voltage_v=float(rec.get("VoltR", math.nan)),
            current_a=current,
            power_w=voltage * current,
            capacity_used_mah=float(rec.get("CurrTot", math.nan)),
            energy_used_wh=float(rec.get("EnrgTot", math.nan)),
            remaining_percent=float(rec.get("RemPct", math.nan)),
        )
        if thr_rec is not None:
            sample.thr_in = float(thr_rec.get("ThrIn", math.nan))
            sample.thr_out = float(thr_rec.get("ThrOut", math.nan))
            sample.desired_speed = float(thr_rec.get("DesSpeed", math.nan))
            sample.speed = float(thr_rec.get("Speed", math.nan))
            if math.isfinite(sample.speed):
                sample.speed_source = "THR.Speed"
            sample.accel_x = float(thr_rec.get("AccX", math.nan))
        gps_rec, gps_index = nearest_gps_record(gps_records, sample.time_us, gps_index)
        if gps_rec is not None:
            sample.speed = float(gps_rec["Spd"])
            sample.speed_source = "GPS.Spd"
            sample.gps_time_offset_s = (int(gps_rec["TimeUS"]) - sample.time_us) / 1_000_000
        output_rec, output_index = nearest_output_record(output_records, sample.time_us, output_index)
        if output_rec is not None:
            sample.left_output_us = float(output_rec.get("C1", math.nan))
            sample.right_output_us = float(output_rec.get("C2", math.nan))
            if output_mapping_supported and math.isfinite(left_trim_us) and math.isfinite(right_trim_us):
                sample.motion_state = (
                    "forward"
                    if is_forward_navigation_command(
                        sample.left_output_us,
                        sample.right_output_us,
                        left_trim_us,
                        right_trim_us,
                    )
                    else "other"
                )
        samples.append(sample)
    return samples


def active_window_from_arm(samples: list[NavSample], arm_events: list[dict[str, Any]]) -> tuple[float, float]:
    armed_start: float | None = None
    armed_end: float | None = None
    for event in arm_events:
        state = int(event.get("ArmState", -1))
        event_time_s = float(event.get("_time_s", math.nan))
        if math.isnan(event_time_s):
            continue
        if state == 1 and armed_start is None:
            armed_start = event_time_s
        elif state == 0 and armed_start is not None and event_time_s > armed_start:
            armed_end = event_time_s
            break
    if armed_start is not None and armed_end is not None:
        return armed_start, armed_end
    if samples:
        return samples[0].time_s, samples[-1].time_s
    return 0.0, 0.0


def analyze_log(path: Path) -> NavigationAnalysis:
    (
        bat_records,
        thr_records,
        gps_records,
        output_records,
        parameters,
        arm_events,
        mode_events,
        messages,
        gps_first,
        gps_last,
        counts,
    ) = parse_log(path)
    samples = combine_samples(
        path,
        bat_records,
        thr_records,
        gps_records,
        output_records,
        parameters,
    )
    start_s, end_s = active_window_from_arm(samples, arm_events)
    active_samples = [sample for sample in samples if start_s <= sample.time_s <= end_s]
    for sample in active_samples:
        sample.navigation_time_s = sample.time_s - start_s
    return NavigationAnalysis(
        log=path.name,
        capacity_mah=BATTERY_CAPACITY_MAH.get(path.stem, 0),
        full_samples=samples,
        active_samples=active_samples,
        active_start_s=start_s,
        active_end_s=end_s,
        parameters=parameters,
        output_mapping_supported=is_supported_output_mapping(parameters),
        arm_events=arm_events,
        mode_events=mode_events,
        messages=messages,
        gps_first_utc=gps_first,
        gps_last_utc=gps_last,
        record_counts=counts,
    )


def valid_values(values: list[float]) -> list[float]:
    return [value for value in values if not math.isnan(value)]


def stats(values: list[float]) -> dict[str, float]:
    valid = valid_values(values)
    if not valid:
        return {"min": math.nan, "mean": math.nan, "max": math.nan}
    return {"min": min(valid), "mean": statistics.fmean(valid), "max": max(valid)}


def summarize(analysis: NavigationAnalysis) -> dict[str, Any]:
    samples = analysis.active_samples
    if not samples:
        raise ValueError(f"No active samples found for {analysis.log}")
    voltage = stats([sample.voltage_v for sample in samples])
    current = stats([sample.current_a for sample in samples])
    power = stats([sample.power_w for sample in samples])
    thr_out = stats([sample.thr_out for sample in samples])
    curve_samples = [sample for sample in samples if is_speed_power_curve_sample(sample)]
    speed = stats([sample.speed for sample in curve_samples])
    valid_speed_count = len(curve_samples)
    duration_min = (samples[-1].navigation_time_s or 0.0) / 60.0
    capacity_used = samples[-1].capacity_used_mah - samples[0].capacity_used_mah
    energy_used = samples[-1].energy_used_wh - samples[0].energy_used_wh
    return {
        "log": analysis.log,
        "battery_capacity_mAh": analysis.capacity_mah,
        "active_start_s": analysis.active_start_s,
        "active_end_s": analysis.active_end_s,
        "endurance_min": duration_min,
        "samples": len(samples),
        "capacity_used_mAh": capacity_used,
        "capacity_used_ratio": capacity_used / analysis.capacity_mah if analysis.capacity_mah else math.nan,
        "energy_used_Wh": energy_used,
        "mAh_per_min": capacity_used / duration_min if duration_min else math.nan,
        "Wh_per_min": energy_used / duration_min if duration_min else math.nan,
        "average_power_from_energy_W": energy_used / (duration_min / 60.0) if duration_min else math.nan,
        "voltage_min_V": voltage["min"],
        "voltage_mean_V": voltage["mean"],
        "voltage_max_V": voltage["max"],
        "current_min_A": current["min"],
        "current_mean_A": current["mean"],
        "current_max_A": current["max"],
        "power_min_W": power["min"],
        "power_mean_W": power["mean"],
        "power_max_W": power["max"],
        "thr_out_min": thr_out["min"],
        "thr_out_mean": thr_out["mean"],
        "thr_out_max": thr_out["max"],
        "speed_valid_samples": valid_speed_count,
        "speed_min_mps": speed["min"],
        "speed_mean_mps": speed["mean"],
        "speed_max_mps": speed["max"],
    }


def write_sample_csv(path: Path, samples: list[NavSample], active_only: bool) -> None:
    fieldnames = [
        "log",
        "time_us",
        "time_s",
        "navigation_time_s",
        "navigation_time_min",
        "voltage_V",
        "resting_voltage_V",
        "current_A",
        "power_W",
        "capacity_used_mAh",
        "energy_used_Wh",
        "remaining_percent",
        "thr_in",
        "thr_out",
        "desired_speed",
        "speed",
        "speed_source",
        "gps_time_offset_s",
        "left_output_us",
        "right_output_us",
        "motion_state",
        "accel_x",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for sample in samples:
            nav_time_s = sample.navigation_time_s if active_only else None
            writer.writerow(
                {
                    "log": sample.log,
                    "time_us": sample.time_us,
                    "time_s": fmt(sample.time_s),
                    "navigation_time_s": "" if nav_time_s is None else fmt(nav_time_s),
                    "navigation_time_min": "" if nav_time_s is None else fmt(nav_time_s / 60.0),
                    "voltage_V": fmt(sample.voltage_v),
                    "resting_voltage_V": fmt(sample.resting_voltage_v),
                    "current_A": fmt(sample.current_a),
                    "power_W": fmt(sample.power_w),
                    "capacity_used_mAh": fmt(sample.capacity_used_mah),
                    "energy_used_Wh": fmt(sample.energy_used_wh),
                    "remaining_percent": fmt(sample.remaining_percent),
                    "thr_in": fmt(sample.thr_in),
                    "thr_out": fmt(sample.thr_out),
                    "desired_speed": fmt(sample.desired_speed),
                    "speed": fmt(sample.speed),
                    "speed_source": sample.speed_source,
                    "gps_time_offset_s": fmt(sample.gps_time_offset_s),
                    "left_output_us": fmt(sample.left_output_us),
                    "right_output_us": fmt(sample.right_output_us),
                    "motion_state": sample.motion_state,
                    "accel_x": fmt(sample.accel_x),
                }
            )


def fmt(value: float) -> str:
    return "" if math.isnan(value) else f"{value:.6f}"


def write_summary_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow({key: fmt(value) if isinstance(value, float) else value for key, value in row.items()})


def navigation_speed_power_points(analysis: NavigationAnalysis) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for sample in analysis.active_samples:
        if not is_speed_power_curve_sample(sample):
            continue
        rows.append(
            {
                "log": analysis.log,
                "navigation_time_s": sample.navigation_time_s or 0.0,
                "navigation_time_min": (sample.navigation_time_s or 0.0) / 60.0,
                "speed_mps": sample.speed,
                "speed_kmh": sample.speed * 3.6,
                "speed_source": sample.speed_source,
                "gps_time_offset_s": sample.gps_time_offset_s,
                "left_output_us": sample.left_output_us,
                "right_output_us": sample.right_output_us,
                "motion_state": sample.motion_state,
                "power_W": sample.power_w,
                "current_A": sample.current_a,
                "voltage_V": sample.voltage_v,
                "thr_in": sample.thr_in,
                "thr_out": sample.thr_out,
            }
        )
    return rows


def is_speed_power_curve_sample(sample: NavSample) -> bool:
    return (
        sample.motion_state == "forward"
        and math.isfinite(sample.speed)
        and math.isfinite(sample.power_w)
        and is_powered_navigation_sample(sample.current_a)
    )


def navigation_speed_power_binned(analysis: NavigationAnalysis) -> list[dict[str, Any]]:
    bins: dict[int, list[NavSample]] = {}
    for sample in analysis.active_samples:
        if not is_speed_power_curve_sample(sample):
            continue
        bin_index = int(sample.speed // SPEED_BIN_MPS)
        bins.setdefault(bin_index, []).append(sample)

    rows: list[dict[str, Any]] = []
    for bin_index in sorted(bins):
        samples = bins[bin_index]
        speeds = [sample.speed for sample in samples]
        powers = [sample.power_w for sample in samples]
        currents = [sample.current_a for sample in samples]
        voltages = [sample.voltage_v for sample in samples]
        thr_out = [sample.thr_out for sample in samples]
        rows.append(
            {
                "log": analysis.log,
                "speed_bin_start_mps": bin_index * SPEED_BIN_MPS,
                "speed_bin_end_mps": (bin_index + 1) * SPEED_BIN_MPS,
                "speed_bin_center_mps": (bin_index + 0.5) * SPEED_BIN_MPS,
                "mean_speed_mps": statistics.fmean(speeds),
                "mean_speed_kmh": statistics.fmean(speeds) * 3.6,
                "mean_power_W": statistics.fmean(powers),
                "mean_current_A": statistics.fmean(currents),
                "mean_voltage_V": statistics.fmean(voltages),
                "mean_thr_out": statistics.fmean(thr_out),
                "samples": len(samples),
            }
        )
    return rows


def write_rows_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    if not rows and fieldnames is None:
        path.write_text("", encoding="utf-8-sig")
        return
    fieldnames = fieldnames or list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: fmt(value) if isinstance(value, float) else value for key, value in row.items()})


def nice_limits(values: list[float]) -> tuple[float, float]:
    valid = valid_values(values)
    if not valid:
        return 0.0, 1.0
    lower = min(valid)
    upper = max(valid)
    if lower == upper:
        return lower - 1.0, upper + 1.0
    pad = (upper - lower) * 0.08
    return lower - pad, upper + pad


def scale_points(
    series: list[tuple[float, float]],
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
    left: float,
    top: float,
    width: float,
    height: float,
) -> str:
    points = []
    x_span = x_max - x_min or 1.0
    y_span = y_max - y_min or 1.0
    for x_value, y_value in series:
        x = left + (x_value - x_min) / x_span * width
        y = top + height - (y_value - y_min) / y_span * height
        points.append(f"{x:.2f},{y:.2f}")
    return " ".join(points)


def make_svg_plot(
    path: Path,
    title: str,
    analyses: list[NavigationAnalysis],
    y_getters: list[tuple[str, str, Callable[[NavSample], float]]],
) -> None:
    width = 1200
    panel_height = 235
    margin_left = 90
    margin_right = 40
    margin_top = 76
    panel_gap = 56
    plot_width = width - margin_left - margin_right
    height = margin_top + len(y_getters) * panel_height + (len(y_getters) - 1) * panel_gap + 70
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd"]
    all_x = [
        (sample.navigation_time_s or 0.0) / 60.0
        for analysis in analyses
        for sample in analysis.active_samples
    ]
    x_min = 0.0
    x_max = max(all_x) if all_x else 1.0
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="{width / 2:.1f}" y="32" text-anchor="middle" font-family="Arial" font-size="22" font-weight="700">{html.escape(title)}</text>',
    ]
    legend_x = margin_left + 180
    legend_y = 56
    for idx, analysis in enumerate(analyses):
        x = legend_x + idx * 230
        color = colors[idx % len(colors)]
        lines.append(f'<line x1="{x}" y1="{legend_y}" x2="{x + 34}" y2="{legend_y}" stroke="{color}" stroke-width="3"/>')
        lines.append(f'<text x="{x + 42}" y="{legend_y + 5}" font-family="Arial" font-size="14">{html.escape(analysis.log)}</text>')

    for panel_idx, (field, ylabel, getter) in enumerate(y_getters):
        top = margin_top + panel_idx * (panel_height + panel_gap)
        y_values = [getter(sample) for analysis in analyses for sample in analysis.active_samples]
        y_min, y_max = nice_limits(y_values)
        lines.append(f'<rect x="{margin_left}" y="{top}" width="{plot_width}" height="{panel_height}" fill="#fafafa" stroke="#cccccc"/>')
        lines.append(f'<text x="24" y="{top + panel_height / 2:.1f}" transform="rotate(-90 24 {top + panel_height / 2:.1f})" font-family="Arial" font-size="15" text-anchor="middle">{html.escape(ylabel)}</text>')
        lines.append(f'<text x="{margin_left}" y="{top - 10}" font-family="Arial" font-size="16" font-weight="700">{html.escape(field)}</text>')
        for grid_i in range(6):
            frac = grid_i / 5
            y = top + panel_height - frac * panel_height
            value = y_min + frac * (y_max - y_min)
            lines.append(f'<line x1="{margin_left}" y1="{y:.2f}" x2="{margin_left + plot_width}" y2="{y:.2f}" stroke="#e6e6e6"/>')
            lines.append(f'<text x="{margin_left - 8}" y="{y + 4:.2f}" font-family="Arial" font-size="12" text-anchor="end">{value:.1f}</text>')
        for grid_i in range(7):
            frac = grid_i / 6
            x = margin_left + frac * plot_width
            value = x_min + frac * (x_max - x_min)
            lines.append(f'<line x1="{x:.2f}" y1="{top}" x2="{x:.2f}" y2="{top + panel_height}" stroke="#eeeeee"/>')
            if panel_idx == len(y_getters) - 1:
                lines.append(f'<text x="{x:.2f}" y="{top + panel_height + 22}" font-family="Arial" font-size="12" text-anchor="middle">{value:.1f}</text>')
        for idx, analysis in enumerate(analyses):
            series = [
                ((sample.navigation_time_s or 0.0) / 60.0, getter(sample))
                for sample in analysis.active_samples
                if not math.isnan(getter(sample))
            ]
            if len(series) > 1200:
                stride = math.ceil(len(series) / 1200)
                series = series[::stride]
            if series:
                points = scale_points(series, x_min, x_max, y_min, y_max, margin_left, top, plot_width, panel_height)
                lines.append(f'<polyline points="{points}" fill="none" stroke="{colors[idx % len(colors)]}" stroke-width="1.7"/>')
    lines.append(f'<text x="{width / 2:.1f}" y="{height - 22}" text-anchor="middle" font-family="Arial" font-size="15">Effective navigation time (min)</text>')
    lines.append("</svg>")
    path.write_text("\n".join(lines), encoding="utf-8")


def make_speed_power_svg(path: Path, title: str, binned_rows: list[dict[str, Any]]) -> None:
    width = 1200
    height = 720
    left = 90
    right = 40
    top = 86
    bottom = 78
    plot_width = width - left - right
    plot_height = height - top - bottom
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd"]
    logs = sorted({str(row["log"]) for row in binned_rows})

    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="{width / 2:.1f}" y="32" text-anchor="middle" font-family="Arial" font-size="22" font-weight="700">{html.escape(title)}</text>',
        f'<text x="{width / 2:.1f}" y="58" text-anchor="middle" font-family="Arial" font-size="14" fill="#555">Forward-command samples only; bin width = {SPEED_BIN_MPS:.2f} m/s, current >= {MIN_CURVE_CURRENT_A:.2f} A</text>',
        f'<rect x="{left}" y="{top}" width="{plot_width}" height="{plot_height}" fill="#fafafa" stroke="#cccccc"/>',
    ]

    if not binned_rows:
        lines.extend(
            [
                f'<text x="{width / 2:.1f}" y="{top + plot_height / 2 - 18:.1f}" text-anchor="middle" font-family="Arial" font-size="22" fill="#555">No valid forward navigation speed samples</text>',
                f'<text x="{width / 2:.1f}" y="{top + plot_height / 2 + 18:.1f}" text-anchor="middle" font-family="Arial" font-size="15" fill="#777">GPS speed, powered state, and matched forward propulsion outputs are required.</text>',
                f'<text x="{width / 2:.1f}" y="{height - 24}" text-anchor="middle" font-family="Arial" font-size="15">GPS navigation speed (m/s)</text>',
                f'<text x="24" y="{top + plot_height / 2:.1f}" transform="rotate(-90 24 {top + plot_height / 2:.1f})" font-family="Arial" font-size="15" text-anchor="middle">Power (W)</text>',
                "</svg>",
            ]
        )
        path.write_text("\n".join(lines), encoding="utf-8")
        return

    x_values = [float(row["mean_speed_mps"]) for row in binned_rows]
    y_values = [float(row["mean_power_W"]) for row in binned_rows]
    x_min, x_max = nice_limits(x_values)
    y_min, y_max = nice_limits(y_values)
    x_min = max(0.0, x_min)

    legend_x = left + 190
    legend_y = 78
    for idx, log in enumerate(logs):
        x = legend_x + idx * 230
        color = colors[idx % len(colors)]
        lines.append(f'<line x1="{x}" y1="{legend_y}" x2="{x + 34}" y2="{legend_y}" stroke="{color}" stroke-width="3"/>')
        lines.append(f'<text x="{x + 42}" y="{legend_y + 5}" font-family="Arial" font-size="14">{html.escape(log)}</text>')

    for grid_i in range(7):
        frac = grid_i / 6
        x = left + frac * plot_width
        value = x_min + frac * (x_max - x_min)
        lines.append(f'<line x1="{x:.2f}" y1="{top}" x2="{x:.2f}" y2="{top + plot_height}" stroke="#eeeeee"/>')
        lines.append(f'<text x="{x:.2f}" y="{top + plot_height + 24}" font-family="Arial" font-size="12" text-anchor="middle">{value:.2f}</text>')

    for grid_i in range(7):
        frac = grid_i / 6
        y = top + plot_height - frac * plot_height
        value = y_min + frac * (y_max - y_min)
        lines.append(f'<line x1="{left}" y1="{y:.2f}" x2="{left + plot_width}" y2="{y:.2f}" stroke="#e6e6e6"/>')
        lines.append(f'<text x="{left - 8}" y="{y + 4:.2f}" font-family="Arial" font-size="12" text-anchor="end">{value:.1f}</text>')

    lines.append(f'<text x="{width / 2:.1f}" y="{height - 24}" text-anchor="middle" font-family="Arial" font-size="15">GPS navigation speed (m/s)</text>')
    lines.append(f'<text x="24" y="{top + plot_height / 2:.1f}" transform="rotate(-90 24 {top + plot_height / 2:.1f})" font-family="Arial" font-size="15" text-anchor="middle">Power (W)</text>')

    for idx, log in enumerate(logs):
        rows = [row for row in binned_rows if row["log"] == log and int(row["samples"]) >= 1]
        rows.sort(key=lambda row: float(row["mean_speed_mps"]))
        series = [(float(row["mean_speed_mps"]), float(row["mean_power_W"])) for row in rows]
        if not series:
            continue
        color = colors[idx % len(colors)]
        points = scale_points(series, x_min, x_max, y_min, y_max, left, top, plot_width, plot_height)
        lines.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="2.2"/>')
        for x_value, y_value in series:
            point = scale_points([(x_value, y_value)], x_min, x_max, y_min, y_max, left, top, plot_width, plot_height)
            x_str, y_str = point.split(",")
            lines.append(f'<circle cx="{x_str}" cy="{y_str}" r="3" fill="{color}" opacity="0.8"/>')

    lines.append("</svg>")
    path.write_text("\n".join(lines), encoding="utf-8")


def write_report(path: Path, analyses: list[NavigationAnalysis], summaries: list[dict[str, Any]]) -> None:
    lines = [
        "# Navigation Endurance and Power Analysis",
        "",
        "## Method",
        "",
        "- Effective navigation window: `ARM` state from armed to disarmed.",
        "- Instantaneous power: `BAT.Volt * BAT.Curr`.",
        "- Speed-power curve: nearest valid `GPS.Spd` within 1.0 s of each `BAT` record. Curve points require `BAT.Curr >= 0.05 A` and a forward propulsion command.",
        "- Forward command: `RCOU.C1/C2` are configured as left/right throttle outputs, both at least 20 us above `SERVO1/2_TRIM`, with a left-right offset difference no greater than 80 us.",
        "- Used capacity: final minus initial `BAT.CurrTot` inside the active window.",
        "- Used energy: final minus initial `BAT.EnrgTot` inside the active window.",
        "",
        "## Summary",
        "",
        "| Log | Battery | Endurance (min) | Capacity used (mAh) | Energy used (Wh) | Mean power (W) | Forward curve samples | Mean forward speed (m/s) | Mean ThrOut |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summaries:
        lines.append(
            "| {log} | {battery_capacity_mAh} | {endurance_min:.2f} | {capacity_used_mAh:.1f} | "
            "{energy_used_Wh:.2f} | {power_mean_W:.2f} | {speed_valid_samples} | {speed_mean_mps:.2f} | {thr_out_mean:.2f} |".format(**row)
        )
    lines.extend(["", "## Per-log Details", ""])
    for analysis, row in zip(analyses, summaries):
        lines.extend(
            [
                f"### {analysis.log}",
                "",
                f"- Battery capacity label: {analysis.capacity_mah} mAh",
                f"- Active window: {analysis.active_start_s:.1f} s to {analysis.active_end_s:.1f} s",
                f"- Endurance: {row['endurance_min']:.2f} min",
                f"- Capacity used: {row['capacity_used_mAh']:.1f} mAh ({row['capacity_used_ratio'] * 100:.1f}% of nominal capacity)",
                f"- Energy used: {row['energy_used_Wh']:.2f} Wh",
                f"- Average power from samples: {row['power_mean_W']:.2f} W",
                f"- Average power from energy: {row['average_power_from_energy_W']:.2f} W",
                f"- Current min/mean/max: {row['current_min_A']:.3f} / {row['current_mean_A']:.3f} / {row['current_max_A']:.3f} A",
                f"- Voltage min/mean/max: {row['voltage_min_V']:.2f} / {row['voltage_mean_V']:.2f} / {row['voltage_max_V']:.2f} V",
                f"- Power min/mean/max: {row['power_min_W']:.2f} / {row['power_mean_W']:.2f} / {row['power_max_W']:.2f} W",
                f"- ThrOut min/mean/max: {row['thr_out_min']:.2f} / {row['thr_out_mean']:.2f} / {row['thr_out_max']:.2f}",
                f"- Forward curve samples: {row['speed_valid_samples']}",
            ]
        )
        if row["speed_valid_samples"] > 0:
            lines.append(f"- Speed min/mean/max: {row['speed_min_mps']:.2f} / {row['speed_mean_mps']:.2f} / {row['speed_max_mps']:.2f} m/s")
            curve_samples = [sample for sample in analysis.active_samples if is_speed_power_curve_sample(sample)]
            gps_speed_count = sum(sample.speed_source == "GPS.Spd" for sample in curve_samples)
            thr_speed_count = sum(sample.speed_source == "THR.Speed" for sample in curve_samples)
            lines.append(f"- Speed source samples: GPS.Spd={gps_speed_count}, THR.Speed fallback={thr_speed_count}")
        else:
            lines.append("- Speed-power curve: unavailable because no valid forward GPS-speed and propulsion-output samples were found.")
        lines.append(f"- Forward-output mapping supported: {analysis.output_mapping_supported}")
        if analysis.gps_first_utc and analysis.gps_last_utc:
            bj_first = analysis.gps_first_utc.astimezone(BEIJING_TZ)
            bj_last = analysis.gps_last_utc.astimezone(BEIJING_TZ)
            lines.append(f"- GPS Beijing time span: {bj_first.isoformat()} to {bj_last.isoformat()}")
        else:
            lines.append("- GPS samples: none recorded in this log.")
        notable = [
            msg
            for msg in analysis.messages
            if "GPS" in msg or "EKF" in msg or "armed" in msg or "disarmed" in msg
        ][:20]
        if notable:
            lines.append("- Notable messages:")
            lines.extend(f"  - {msg}" for msg in notable)
        lines.append("")
    lines.extend(
        [
            "## Notes",
            "",
            "- The recorded battery current is very low for a propulsion test, with mean current below 1 A. If the propulsion system should draw much more, verify the current sensor calibration and whether the logged `BAT` instance measures the whole vehicle power bus.",
            "- GPS speed is ground speed. Current, wind, and sideslip effects are not removed, so the curve should be interpreted as ground-speed power rather than through-water speed power.",
            "- A speed-power point is kept only when a finite GPS.Spd record occurs within 1.0 s of the BAT record, both left/right propulsion outputs indicate forward motion, and battery current is at least 0.05 A. The complete active-sample CSV retains excluded points and their `motion_state` for review.",
            "",
            "## Generated Files",
            "",
            "- `Navigation/Analysis/data/navigation_power_summary.csv`",
            "- `Navigation/Analysis/data/navigation_power_speed_points.csv`",
            "- `Navigation/Analysis/data/navigation_power_speed_binned.csv`",
            "- `Navigation/Analysis/data/*_navigation_full.csv`",
            "- `Navigation/Analysis/data/*_navigation_active.csv`",
            "- `Navigation/Analysis/figures/navigation_power.svg`",
            "- `Navigation/Analysis/figures/navigation_power_vs_speed.svg`",
            "",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    script_dir = Path(__file__).resolve().parent
    analysis_dir = script_dir.parent
    navigation_dir = analysis_dir.parent
    logs_dir = navigation_dir / "Logs"
    data_dir = analysis_dir / "data"
    figures_dir = analysis_dir / "figures"
    reports_dir = analysis_dir / "reports"
    for directory in (data_dir, figures_dir, reports_dir):
        directory.mkdir(parents=True, exist_ok=True)

    log_paths = sorted(logs_dir.glob("*.BIN"))
    if not log_paths:
        raise FileNotFoundError(f"No .BIN logs found in {logs_dir}")

    analyses = [analyze_log(path) for path in log_paths]
    summaries = [summarize(analysis) for analysis in analyses]
    all_speed_power_points: list[dict[str, Any]] = []
    all_speed_power_binned: list[dict[str, Any]] = []
    for analysis in analyses:
        stem = Path(analysis.log).stem
        points = navigation_speed_power_points(analysis)
        binned = navigation_speed_power_binned(analysis)
        all_speed_power_points.extend(points)
        all_speed_power_binned.extend(binned)
        write_sample_csv(data_dir / f"{stem}_navigation_full.csv", analysis.full_samples, active_only=False)
        write_sample_csv(data_dir / f"{stem}_navigation_active.csv", analysis.active_samples, active_only=True)
        write_rows_csv(
            data_dir / f"{stem}_navigation_speed_power_points.csv",
            points,
            [
                "log",
                "navigation_time_s",
                "navigation_time_min",
                "speed_mps",
                "speed_kmh",
                "speed_source",
                "gps_time_offset_s",
                "left_output_us",
                "right_output_us",
                "motion_state",
                "power_W",
                "current_A",
                "voltage_V",
                "thr_in",
                "thr_out",
            ],
        )
        write_rows_csv(
            data_dir / f"{stem}_navigation_speed_power_binned.csv",
            binned,
            [
                "log",
                "speed_bin_start_mps",
                "speed_bin_end_mps",
                "speed_bin_center_mps",
                "mean_speed_mps",
                "mean_speed_kmh",
                "mean_power_W",
                "mean_current_A",
                "mean_voltage_V",
                "mean_thr_out",
                "samples",
            ],
        )
    write_summary_csv(data_dir / "navigation_power_summary.csv", summaries)
    write_rows_csv(
        data_dir / "navigation_power_speed_points.csv",
        all_speed_power_points,
        [
            "log",
            "navigation_time_s",
            "navigation_time_min",
            "speed_mps",
            "speed_kmh",
            "speed_source",
            "gps_time_offset_s",
            "left_output_us",
            "right_output_us",
            "motion_state",
            "power_W",
            "current_A",
            "voltage_V",
            "thr_in",
            "thr_out",
        ],
    )
    write_rows_csv(
        data_dir / "navigation_power_speed_binned.csv",
        all_speed_power_binned,
        [
            "log",
            "speed_bin_start_mps",
            "speed_bin_end_mps",
            "speed_bin_center_mps",
            "mean_speed_mps",
            "mean_speed_kmh",
            "mean_power_W",
            "mean_current_A",
            "mean_voltage_V",
            "mean_thr_out",
            "samples",
        ],
    )
    make_svg_plot(
        figures_dir / "navigation_power.svg",
        "Navigation endurance and power",
        analyses,
        [
            ("Voltage", "Voltage (V)", lambda s: s.voltage_v),
            ("Current", "Current (A)", lambda s: s.current_a),
            ("Power", "Power (W)", lambda s: s.power_w),
            ("Throttle Output", "ThrOut", lambda s: s.thr_out),
        ],
    )
    make_speed_power_svg(
        figures_dir / "navigation_power_vs_speed.svg",
        "Navigation power vs speed",
        all_speed_power_binned,
    )
    write_report(reports_dir / "navigation_power_report.md", analyses, summaries)

    for row in summaries:
        print(
            "{log}: endurance={endurance_min:.2f} min, mean_power={power_mean_W:.2f} W, "
            "valid_speed_samples={speed_valid_samples}, energy={energy_used_Wh:.2f} Wh, capacity={capacity_used_mAh:.1f} mAh".format(**row)
        )


if __name__ == "__main__":
    main()
