# Navigation Analysis Workspace

This folder keeps navigation-log analysis code and generated outputs separated.

## Directory Layout

- `scripts/`: Python analysis scripts.
- `data/`: Generated CSV files.
- `figures/`: Generated SVG figures.
- `reports/`: Generated Markdown reports.
- `log_inventory.md` and `log_message_inventory.csv`: Message inventory from the earlier log scan.

## Run

From the repository root:

```powershell
D:\anaconda3\envs\markitdown\python.exe Navigation\Analysis\scripts\analyze_navigation_power.py
```

The script analyzes all `.BIN` files in `Navigation/Logs`.

## Current Active-window Rule

The effective navigation segment is detected from `ARM` events: the first armed state to the following disarmed state. This is used instead of a current threshold because `00000131.BIN` records very low battery current throughout the test.

## Speed-power Curve

The script uses the nearest finite `GPS.Spd` sample within 1.0 s of each `BAT` sample for the navigation speed-power curve. Curve points must also have `BAT.Curr >= 0.05 A` and a forward command: `RCOU.C1/C2` configured as left/right throttle, both at least 20 us above their trim values, with a left-right offset difference no greater than 80 us. This excludes reverse, differential-turn, idle, and zero-current post-navigation states.

`00000131.BIN` has no valid speed samples, so it remains absent from the curve. Future logs with valid GPS speed data automatically populate:

- `data/navigation_power_speed_points.csv`
- `data/navigation_power_speed_binned.csv`
- `figures/navigation_power_vs_speed.svg`
