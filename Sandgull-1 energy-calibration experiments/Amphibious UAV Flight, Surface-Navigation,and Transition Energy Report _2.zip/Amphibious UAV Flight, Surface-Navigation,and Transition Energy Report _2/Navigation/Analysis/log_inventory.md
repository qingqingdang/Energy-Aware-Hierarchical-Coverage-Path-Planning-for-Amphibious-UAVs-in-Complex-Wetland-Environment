# Navigation Log Inventory

## 00000131.BIN

- Size: 127.24 MB
- Records decoded: 3224486
- Message types: 173
- Resync errors: 0
- Top messages: IMU:428967, XKF4:285979, XKF1:285979, XKF2:285979, XKF3:285979, XKFS:285978, XKQ:285978, ATT:142990, XKF5:142990, PIDS:142989, PIDA:142989, VIBE:85791, RCIN:28601, RCI2:28601, POWR:28598, BAT:28598, DCM:28598, EAHR:28598, BARO:28597, THR:28597

### Major Data Categories

- EKF / estimator: 1871442 records
- Sensors / IMU: 514758 records
- PID / control: 285978 records
- Other: 235475 records
- Attitude: 142990 records
- RC input/output: 57198 records
- Battery / power: 57196 records
- Sensors / barometer: 28597 records
- Navigation control: 28597 records
- Parameters / metadata: 1659 records
- State / messages: 589 records
- State / events: 7 records

### Important Recorded Channels

- BAT: 28598 records; fields: TimeUS, Inst, Volt, VoltR, Curr, CurrTot, EnrgTot, Temp, Res, RemPct, H, SH
- ATT: 142990 records; fields: TimeUS, DesRoll, Roll, DesPitch, Pitch, DesYaw, Yaw, AEKF
- BARO: 28597 records; fields: TimeUS, I, Alt, AltAMSL, Press, Temp, CRt, SMS, Offset, GndTemp, Health
- IMU: 428967 records; fields: TimeUS, I, GyrX, GyrY, GyrZ, AccX, AccY, AccZ, EG, EA, T, GH, AH, GHz, AHz
- VIBE: 85791 records; fields: TimeUS, IMU, VibeX, VibeY, VibeZ, Clip
- RCIN: 28601 records; fields: TimeUS, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14
- RCOU: 28597 records; fields: TimeUS, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14
- MODE: 1 records; fields: TimeUS, Mode, ModeNum, Rsn
- ARM: 3 records; fields: TimeUS, ArmState, ArmChecks, Forced, Method
- EV: 3 records; fields: TimeUS, Id
- NTUN: 28597 records; fields: TimeUS, WpDist, WpBrg, DesYaw, Yaw, XTrack
- MSG: 589 records; fields: TimeUS, Message
- VER: 1 records; fields: TimeUS, BT, BST, Maj, Min, Pat, FWT, GH, FWS, APJ, BU, FV
- PARM: 1239 records; fields: TimeUS, Name, Value, Default

### First MSG Text Entries

- Throttle armed
- ArduRover V4.6.2 (1ebd4d99)
- ChibiOS: 88b84600
- CUAVv5Nano 00170031 30335110 36323635
- Param space used: 1352/5120
- RC Protocol: SBUS
- RCOut: PWM:1-11
- New mission
- New rally
- New fence
- Throttle disarmed
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- Throttle armed
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data
- EKF3 waiting for GPS config data

### Sample Values

- BAT: TimeUS=55864572, Inst=0, Volt=25.15, VoltR=25.15, Curr=0, CurrTot=0.2525, EnrgTot=0.006349, Temp=0, Res=0.04265, RemPct=99
- ATT: TimeUS=55862857, DesRoll=0, Roll=-4.089, DesPitch=0, Pitch=-18.16, DesYaw=0, Yaw=0.1814, AEKF=0
- BARO: TimeUS=55943512, I=0, Alt=0.9821, AltAMSL=0.9821, Press=1.006e+05, Temp=33.56, CRt=0.04635, SMS=55943, Offset=0, GndTemp=31.95
- IMU: TimeUS=55863935, I=0, GyrX=-0.0006543, GyrY=0.001086, GyrZ=0.0005198, AccX=-3.178, AccY=0.4459, AccZ=-9.192, EG=0, EA=0
- VIBE: TimeUS=55943638, IMU=0, VibeX=0.0553, VibeY=0.09368, VibeZ=0.05195, Clip=0
- RCIN: TimeUS=55844036, C1=1515, C2=1518, C3=1095, C4=1519, C5=1095, C6=1095, C7=1934, C8=1380, C9=1515
- RCOU: TimeUS=55943620, C1=1496, C2=1483, C3=0, C4=0, C5=0, C6=0, C7=0, C8=0, C9=0
- MODE: TimeUS=57883572, Mode=0, ModeNum=0, Rsn=1
- ARM: TimeUS=60244508, ArmState=0, ArmChecks=0, Forced=0, Method=2
- EV: TimeUS=60244518, Id=11
- NTUN: TimeUS=55943578, WpDist=0, WpBrg=0, DesYaw=0, Yaw=18, XTrack=0
- MSG: TimeUS=55843769, Message=Throttle armed
- VER: TimeUS=57863910, BT=10, BST=5013, Maj=4, Min=6, Pat=2, FWT=255, GH=515722649, FWS=ArduRover V4.6.2 (1ebd4d99), APJ=50
- PARM: TimeUS=55904528, Name=FORMAT_VERSION, Value=16, Default=16

