"""Reproduce the numerical results used in the LaTeX energy report."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXPERIMENT_ROOT = ROOT.parent
PLOT_ROOT = EXPERIMENT_ROOT / "plot"
OUTPUT_DIR = ROOT / "report_data"
EXAMPLE_LOG = "00000162.BIN"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def calculate_reference_ratio() -> tuple[float, list[dict[str, float | str]]]:
    navigation = read_csv(PLOT_ROOT / "data" / "table_navigation_speed_power_energy.csv")
    flight = read_csv(PLOT_ROOT / "data" / "table_flight157_speed_power_energy.csv")

    water = next(row for row in navigation if float(row["speed_mps"]) == 0.4)
    flight_reference = next(row for row in flight if float(row["speed_mps"]) == 3.0)

    flight_speed = float(flight_reference["speed_mps"])
    flight_power = float(flight_reference["power_W"])
    flight_energy_per_m = float(flight_reference["energy_per_m_J"])
    water_energy_per_m = float(water["power_W"]) / float(water["speed_mps"])
    ratio = flight_energy_per_m / water_energy_per_m

    rows: list[dict[str, float | str]] = [
        {
            "mode": "surface_navigation",
            "log": "00000133.BIN",
            "speed_mps": float(water["speed_mps"]),
            "power_W": float(water["power_W"]),
            "energy_per_m_J": water_energy_per_m,
            "derivation": "measured speed-bin value",
        },
        {
            "mode": "aerial_flight",
            "log": "00000157.BIN",
            "speed_mps": flight_speed,
            "power_W": flight_power,
            "energy_per_m_J": flight_energy_per_m,
            "derivation": "measured speed-bin value",
        },
    ]
    return ratio, rows


def calculate_three_meter_transitions() -> list[dict[str, float | str]]:
    energy_rows = read_csv(PLOT_ROOT / "data" / "table_takeoff_landing_energy.csv")
    phase_rows = read_csv(PLOT_ROOT / "data" / "flight_takeoff_landing_phases.csv")
    phase_definition = next(
        row for row in phase_rows if row["log"] == EXAMPLE_LOG
    )
    full_height_m = float(phase_definition["cruise_alt_m"])

    results: list[dict[str, float | str]] = []
    for phase in ("takeoff", "landing"):
        row = next(
            item
            for item in energy_rows
            if item["log"] == EXAMPLE_LOG and item["phase"] == phase
        )
        full_energy_j = float(row["energy_J"])
        scaled_energy_j = full_energy_j * 3.0 / full_height_m
        results.append(
            {
                "log": EXAMPLE_LOG,
                "phase": phase,
                "full_height_m": full_height_m,
                "full_duration_s": float(row["duration_s"]),
                "full_mean_power_W": float(row["mean_power_W"]),
                "full_energy_J": full_energy_j,
                "full_energy_kJ": full_energy_j / 1000.0,
                "target_height_m": 3.0,
                "scaled_energy_J": scaled_energy_j,
                "scaled_energy_kJ": scaled_energy_j / 1000.0,
            }
        )
    return results


def write_csv(path: Path, rows: list[dict[str, float | str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    ratio, reference_rows = calculate_reference_ratio()
    for row in reference_rows:
        row["flight_to_navigation_ratio"] = ratio
    write_csv(OUTPUT_DIR / "reference_energy_ratio.csv", reference_rows)

    transition_rows = calculate_three_meter_transitions()
    water_energy_per_m = float(reference_rows[0]["energy_per_m_J"])
    for row in transition_rows:
        row["normalized_energy"] = float(row["scaled_energy_J"]) / water_energy_per_m
    write_csv(OUTPUT_DIR / "transition_3m_example.csv", transition_rows)

    print(f"Reference flight/navigation energy ratio: {ratio:.4f}")
    for row in transition_rows:
        print(
            f"{row['phase']}: full={float(row['full_energy_kJ']):.4f} kJ, "
            f"3m-equivalent={float(row['scaled_energy_kJ']):.4f} kJ, "
            f"normalized={float(row['normalized_energy']):.1f}"
        )


if __name__ == "__main__":
    main()
